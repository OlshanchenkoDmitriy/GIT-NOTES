
  # Инструмент пакетной обработки текста

  This is a code bundle for Инструмент пакетной обработки текста. The original project is available at https://www.figma.com/design/Rf0xKvFfSq4f79PdKaqcO4/%D0%98%D0%BD%D1%81%D1%82%D1%80%D1%83%D0%BC%D0%B5%D0%BD%D1%82-%D0%BF%D0%B0%D0%BA%D0%B5%D1%82%D0%BD%D0%BE%D0%B9-%D0%BE%D0%B1%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B8-%D1%82%D0%B5%D0%BA%D1%81%D1%82%D0%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  