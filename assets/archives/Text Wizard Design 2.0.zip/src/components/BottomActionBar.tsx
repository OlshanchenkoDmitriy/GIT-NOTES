import React from 'react';
import { Button } from './ui/button';
import { Undo, Redo, Copy, Play, RotateCcw } from 'lucide-react';
import { toastHelpers } from './Toast';

interface BottomActionBarProps {
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onApply: () => void;
  onReset: () => void;
  processedText: string;
  canApply: boolean;
}

export function BottomActionBar({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onApply,
  onReset,
  processedText,
  canApply
}: BottomActionBarProps) {
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(processedText);
      toastHelpers.success('Текст скопирован');
    } catch (error) {
      toastHelpers.error('Ошибка копирования');
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-sm border-t border-border">
      {/* Safe area wrapper для учета системных элементов */}
      <div className="safe-area-inset-bottom">
        <div className="container mx-auto max-w-7xl px-4 py-3 lg:py-4">
          {/* Мобильная версия - компактная компоновка */}
          <div className="flex items-center justify-between gap-2 lg:hidden">
            {/* Левая группа - История (компактная) */}
            <div className="flex gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={onUndo}
                disabled={!canUndo}
                className="h-10 w-10 p-0 min-h-[44px] min-w-[44px]"
                aria-label="Отменить"
              >
                <Undo className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onRedo}
                disabled={!canRedo}
                className="h-10 w-10 p-0 min-h-[44px] min-w-[44px]"
                aria-label="Повторить"
              >
                <Redo className="h-4 w-4" />
              </Button>
            </div>

            {/* Центральная группа - Дополнительные действия */}
            <div className="flex gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopy}
                disabled={!processedText}
                className="h-10 w-10 p-0 min-h-[44px] min-w-[44px]"
                aria-label="Копировать результат"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onReset}
                className="h-10 w-10 p-0 min-h-[44px] min-w-[44px]"
                aria-label="Сбросить все"
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>

            {/* Правая группа - Главное действие */}
            <div>
              <Button
                size="sm"
                onClick={onApply}
                disabled={!canApply}
                className="h-10 px-4 min-h-[44px] text-sm font-medium"
              >
                <Play className="h-4 w-4 mr-2" />
                Применить
              </Button>
            </div>
          </div>

          {/* Десктопная версия - полная компоновка */}
          <div className="hidden lg:flex items-center justify-between gap-3">
            {/* Левая группа - История */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={onUndo}
                disabled={!canUndo}
                className="flex items-center gap-2"
              >
                <Undo className="h-4 w-4" />
                <span>Отменить</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onRedo}
                disabled={!canRedo}
                className="flex items-center gap-2"
              >
                <Redo className="h-4 w-4" />
                <span>Повторить</span>
              </Button>
            </div>

            {/* Центральная группа - Основные действия */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopy}
                disabled={!processedText}
                className="flex items-center gap-2"
              >
                <Copy className="h-4 w-4" />
                <span>Копировать</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={onReset}
                className="flex items-center gap-2"
              >
                <RotateCcw className="h-4 w-4" />
                <span>Сбросить</span>
              </Button>
            </div>

            {/* Правая группа - Основное действие */}
            <div>
              <Button
                size="sm"
                onClick={onApply}
                disabled={!canApply}
                className="flex items-center gap-2"
              >
                <Play className="h-4 w-4" />
                <span>Применить</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}