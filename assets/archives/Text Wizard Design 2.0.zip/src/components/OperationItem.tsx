import React, { useState } from 'react';
import { Operation, OperationType, CaseType, SortType, LineNumberFormat } from '../types';
import { operationLabels } from '../utils/textProcessing';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Separator } from './ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { 
  ChevronDown, 
  ChevronUp, 
  ChevronRight,
  Trash2, 
  Eye, 
  EyeOff, 
  ArrowUp, 
  ArrowDown, 
  GripVertical,
  AlertCircle,
  Info,
  CheckCircle
} from 'lucide-react';

interface OperationItemProps {
  operation: Operation;
  onUpdate: (operation: Operation) => void;
  onRemove: () => void;
  onPreview: () => void;
  isFirst?: boolean;
  isLast?: boolean;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
}

export function OperationItem({
  operation,
  onUpdate,
  onRemove,
  onPreview,
  isFirst = false,
  isLast = false,
  onMoveUp,
  onMoveDown
}: OperationItemProps) {
  const [isCollapsed, setIsCollapsed] = useState(operation.collapsed ?? false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const updateSettings = (newSettings: Record<string, any>) => {
    const updatedOperation = {
      ...operation,
      settings: { ...operation.settings, ...newSettings }
    };
    onUpdate(updatedOperation);
  };

  const updateEnabled = (enabled: boolean) => {
    onUpdate({ ...operation, enabled });
  };

  const toggleCollapsed = () => {
    const newCollapsed = !isCollapsed;
    setIsCollapsed(newCollapsed);
    onUpdate({ ...operation, collapsed: newCollapsed });
  };

  const validateRegexPattern = (pattern: string) => {
    if (!pattern) {
      setValidationError(null);
      return;
    }
    
    try {
      new RegExp(pattern);
      setValidationError(null);
    } catch (error) {
      setValidationError('Неверное регулярное выражение');
    }
  };

  const renderOperationSettings = () => {
    switch (operation.type) {
      case 'removeCharacters':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`chars-${operation.id}`}>Символы для удаления</Label>
              <Input
                id={`chars-${operation.id}`}
                placeholder="Например: .,!?"
                value={operation.settings.characters || ''}
                onChange={(e) => updateSettings({ characters: e.target.value })}
                className="font-mono"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id={`chains-${operation.id}`}
                checked={operation.settings.treatChainsAsTokens || false}
                onCheckedChange={(checked) => updateSettings({ treatChainsAsTokens: checked })}
              />
              <Label htmlFor={`chains-${operation.id}`}>
                Обрабатывать цепочки как отдельные токены
              </Label>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Если включено, несколько одинаковых символов подряд удаляются как один блок</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        );

      case 'regexReplace':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`pattern-${operation.id}`}>Регулярное выражение</Label>
              <Input
                id={`pattern-${operation.id}`}
                placeholder="Например: \d+"
                value={operation.settings.pattern || ''}
                onChange={(e) => {
                  updateSettings({ pattern: e.target.value });
                  validateRegexPattern(e.target.value);
                }}
                className={`font-mono ${validationError ? 'border-destructive' : ''}`}
              />
              {validationError && (
                <div className="flex items-center gap-2 mt-1 text-sm text-destructive">
                  <AlertCircle className="h-3 w-3" />
                  <span>{validationError}</span>
                </div>
              )}
            </div>
            
            <div>
              <Label htmlFor={`replacement-${operation.id}`}>Замена</Label>
              <Input
                id={`replacement-${operation.id}`}
                placeholder="Текст замены (или пусто для удаления)"
                value={operation.settings.replacement || ''}
                onChange={(e) => updateSettings({ replacement: e.target.value })}
                className="font-mono"
              />
            </div>

            <div>
              <Label htmlFor={`flags-${operation.id}`}>Флаги</Label>
              <Input
                id={`flags-${operation.id}`}
                placeholder="g, i, m"
                value={operation.settings.flags || 'g'}
                onChange={(e) => updateSettings({ flags: e.target.value })}
                className="font-mono"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`highlight-${operation.id}`}
                checked={operation.settings.highlightMatches || false}
                onCheckedChange={(checked) => updateSettings({ highlightMatches: checked })}
              />
              <Label htmlFor={`highlight-${operation.id}`}>
                Подсвечивать совпадения в предпросмотре
              </Label>
            </div>
          </div>
        );

      case 'changeCase':
        return (
          <div>
            <Label htmlFor={`case-${operation.id}`}>Тип изменения регистра</Label>
            <Select 
              value={operation.settings.caseType || 'lowercase'} 
              onValueChange={(value) => updateSettings({ caseType: value as CaseType })}
            >
              <SelectTrigger id={`case-${operation.id}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="uppercase">ВЕРХНИЙ РЕГИСТР</SelectItem>
                <SelectItem value="lowercase">нижний регистр</SelectItem>
                <SelectItem value="capitalize">Заглавные Буквы</SelectItem>
                <SelectItem value="sentence">Как в предложении</SelectItem>
                <SelectItem value="invert">иНВЕРТИРОВАТЬ рЕГИСТР</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );

      case 'deduplicate':
        return (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id={`case-sensitive-${operation.id}`}
                checked={operation.settings.caseSensitive ?? true}
                onCheckedChange={(checked) => updateSettings({ caseSensitive: checked })}
              />
              <Label htmlFor={`case-sensitive-${operation.id}`}>
                Учитывать регистр
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`keep-first-${operation.id}`}
                checked={operation.settings.keepFirst ?? true}
                onCheckedChange={(checked) => updateSettings({ keepFirst: checked })}
              />
              <Label htmlFor={`keep-first-${operation.id}`}>
                Оставлять первые вхождения (иначе последние)
              </Label>
            </div>
          </div>
        );

      case 'removeEmptyLines':
        return (
          <div className="flex items-center space-x-2">
            <Switch
              id={`whitespace-only-${operation.id}`}
              checked={operation.settings.includeWhitespaceOnly ?? true}
              onCheckedChange={(checked) => updateSettings({ includeWhitespaceOnly: checked })}
            />
            <Label htmlFor={`whitespace-only-${operation.id}`}>
              Удалять строки только с пробелами
            </Label>
          </div>
        );

      case 'trimWhitespace':
        return (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch
                id={`trim-start-${operation.id}`}
                checked={operation.settings.trimStart ?? true}
                onCheckedChange={(checked) => updateSettings({ trimStart: checked })}
              />
              <Label htmlFor={`trim-start-${operation.id}`}>
                Удалять пробелы в начале
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`trim-end-${operation.id}`}
                checked={operation.settings.trimEnd ?? true}
                onCheckedChange={(checked) => updateSettings({ trimEnd: checked })}
              />
              <Label htmlFor={`trim-end-${operation.id}`}>
                Удалять пробелы в конце
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`per-line-${operation.id}`}
                checked={operation.settings.perLine ?? true}
                onCheckedChange={(checked) => updateSettings({ perLine: checked })}
              />
              <Label htmlFor={`per-line-${operation.id}`}>
                Обрабатывать каждую строку отдельно
              </Label>
            </div>
          </div>
        );

      case 'addPrefixSuffix':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`prefix-${operation.id}`}>Префикс</Label>
              <Input
                id={`prefix-${operation.id}`}
                placeholder="Текст в начале каждой строки"
                value={operation.settings.prefix || ''}
                onChange={(e) => updateSettings({ prefix: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor={`suffix-${operation.id}`}>Суффикс</Label>
              <Input
                id={`suffix-${operation.id}`}
                placeholder="Текст в конце каждой строки"
                value={operation.settings.suffix || ''}
                onChange={(e) => updateSettings({ suffix: e.target.value })}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`empty-lines-${operation.id}`}
                checked={operation.settings.applyToEmptyLines ?? false}
                onCheckedChange={(checked) => updateSettings({ applyToEmptyLines: checked })}
              />
              <Label htmlFor={`empty-lines-${operation.id}`}>
                Применять к пустым строкам
              </Label>
            </div>
          </div>
        );

      case 'sortLines':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`sort-type-${operation.id}`}>Тип сортировки</Label>
              <Select 
                value={operation.settings.sortType || 'alphabetical'} 
                onValueChange={(value) => updateSettings({ sortType: value as SortType })}
              >
                <SelectTrigger id={`sort-type-${operation.id}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="alphabetical">По алфавиту</SelectItem>
                  <SelectItem value="length">По длине</SelectItem>
                  <SelectItem value="random">Случайно</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`ascending-${operation.id}`}
                checked={operation.settings.ascending ?? true}
                onCheckedChange={(checked) => updateSettings({ ascending: checked })}
              />
              <Label htmlFor={`ascending-${operation.id}`}>
                По возрастанию (иначе по убыванию)
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`case-sensitive-sort-${operation.id}`}
                checked={operation.settings.caseSensitive ?? false}
                onCheckedChange={(checked) => updateSettings({ caseSensitive: checked })}
              />
              <Label htmlFor={`case-sensitive-sort-${operation.id}`}>
                Учитывать регистр
              </Label>
            </div>
          </div>
        );

      case 'addLineNumbers':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`format-${operation.id}`}>Формат нумерации</Label>
              <Select 
                value={operation.settings.format || 'decimal'} 
                onValueChange={(value) => updateSettings({ format: value as LineNumberFormat })}
              >
                <SelectTrigger id={`format-${operation.id}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="decimal">1. 2. 3.</SelectItem>
                  <SelectItem value="parentheses">(1) (2) (3)</SelectItem>
                  <SelectItem value="padded">01. 02. 03.</SelectItem>
                  <SelectItem value="brackets">[1] [2] [3]</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor={`start-number-${operation.id}`}>Начальный номер</Label>
              <Input
                id={`start-number-${operation.id}`}
                type="number"
                min="0"
                value={operation.settings.startNumber || 1}
                onChange={(e) => updateSettings({ startNumber: parseInt(e.target.value) || 1 })}
              />
            </div>

            <div>
              <Label htmlFor={`separator-${operation.id}`}>Разделитель</Label>
              <Input
                id={`separator-${operation.id}`}
                placeholder=". "
                value={operation.settings.separator || '. '}
                onChange={(e) => updateSettings({ separator: e.target.value })}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`pad-zeros-${operation.id}`}
                checked={operation.settings.padZeros ?? false}
                onCheckedChange={(checked) => updateSettings({ padZeros: checked })}
              />
              <Label htmlFor={`pad-zeros-${operation.id}`}>
                Дополнять нулями (01, 02...)
              </Label>
            </div>
          </div>
        );

      case 'sliceHead':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`characters-${operation.id}`}>Количество символов</Label>
              <Input
                id={`characters-${operation.id}`}
                type="number"
                min="1"
                value={operation.settings.characters || 100}
                onChange={(e) => updateSettings({ characters: parseInt(e.target.value) || 100 })}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`preserve-words-${operation.id}`}
                checked={operation.settings.preserveWords ?? true}
                onCheckedChange={(checked) => updateSettings({ preserveWords: checked })}
              />
              <Label htmlFor={`preserve-words-${operation.id}`}>
                Не разрывать слова
              </Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id={`add-ellipsis-${operation.id}`}
                checked={operation.settings.addEllipsis ?? true}
                onCheckedChange={(checked) => updateSettings({ addEllipsis: checked })}
              />
              <Label htmlFor={`add-ellipsis-${operation.id}`}>
                Добавлять многоточие
              </Label>
            </div>
          </div>
        );

      default:
        return <div className="text-muted-foreground text-sm">Настройки недоступны</div>;
    }
  };

  const getOperationIcon = () => {
    if (validationError) {
      return <AlertCircle className="h-4 w-4 text-destructive" />;
    }
    if (operation.enabled) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    return <Eye className="h-4 w-4 text-muted-foreground" />;
  };

  return (
    <Card className={`${operation.enabled ? 'border-primary/50' : 'border-dashed'} transition-all duration-200`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 cursor-grab active:cursor-grabbing"
              title="Перетащить для изменения порядка"
            >
              <GripVertical className="h-3 w-3" />
            </Button>
            
            <Switch
              checked={operation.enabled}
              onCheckedChange={updateEnabled}
              className="shrink-0"
            />
            
            <Collapsible open={!isCollapsed} onOpenChange={() => {}}>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleCollapsed}
                  className="flex items-center gap-2 p-0 h-auto font-medium"
                >
                  {isCollapsed ? (
                    <ChevronRight className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                  <span>{operationLabels[operation.type]}</span>
                </Button>
              </CollapsibleTrigger>
            </Collapsible>

            {getOperationIcon()}

            <Badge variant="outline" className="text-xs">
              #{operation.id.slice(-4)}
            </Badge>
          </div>

          <div className="flex items-center gap-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onPreview}
                    className="h-8 w-8 p-0"
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Предварительный просмотр до этой операции</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            {onMoveUp && !isFirst && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onMoveUp}
                className="h-8 w-8 p-0"
                title="Переместить вверх"
              >
                <ArrowUp className="h-4 w-4" />
              </Button>
            )}

            {onMoveDown && !isLast && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onMoveDown}
                className="h-8 w-8 p-0"
                title="Переместить вниз"
              >
                <ArrowDown className="h-4 w-4" />
              </Button>
            )}

            <Button
              variant="ghost"
              size="sm"
              onClick={onRemove}
              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
              title="Удалить операцию"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <Collapsible open={!isCollapsed}>
        <CollapsibleContent>
          <CardContent className="pt-0">
            <Separator className="mb-4" />
            {renderOperationSettings()}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}