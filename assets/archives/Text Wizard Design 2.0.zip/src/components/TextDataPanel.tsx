import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { calculateTextStats, formatStats, formatStatsShort } from '../utils/textStats';
import { Upload, Download, Copy, ClipboardPaste, RotateCcw, Eye, AlertTriangle } from 'lucide-react';
import { toastHelpers } from './Toast';
import { useDebouncedState } from '../utils/debounce';

interface TextDataPanelProps {
  originalText: string;
  processedText: string;
  onOriginalTextChange: (text: string) => void;
  onLoadFile: () => void;
  onDownload: () => void;
  previewInfo?: string;
  className?: string;
}

export function TextDataPanel({
  originalText,
  processedText,
  onOriginalTextChange,
  onLoadFile,
  onDownload,
  previewInfo,
  className = ''
}: TextDataPanelProps) {
  const [activeTab, setActiveTab] = useState<'input' | 'result'>('input');
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  
  // Debounced состояние для текста
  const [immediateText, debouncedText, setImmediateText, isTextPending] = useDebouncedState(originalText, 300);

  // Обновляем родительское состояние при изменении debounced текста
  React.useEffect(() => {
    if (debouncedText !== originalText) {
      onOriginalTextChange(debouncedText);
    }
  }, [debouncedText, originalText, onOriginalTextChange]);

  // Статистика для обоих текстов
  const originalStats = useMemo(() => calculateTextStats(originalText), [originalText]);
  const processedStats = useMemo(() => calculateTextStats(processedText), [processedText]);

  const hasProcessedText = processedText.length > 0;
  const hasChanges = originalText !== processedText;

  // Обработчики
  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setImmediateText(text);
      toastHelpers.success('Текст вставлен из буфера обмена');
    } catch (error) {
      toastHelpers.error('Ошибка вставки из буфера обмена');
    }
  };

  const handleCopyOriginal = async () => {
    try {
      await navigator.clipboard.writeText(originalText);
      toastHelpers.success('Исходный текст скопирован');
    } catch (error) {
      toastHelpers.error('Ошибка копирования');
    }
  };

  const handleCopyProcessed = async () => {
    try {
      await navigator.clipboard.writeText(processedText);
      toastHelpers.success('Результат скопирован');
    } catch (error) {
      toastHelpers.error('Ошибка копирования');
    }
  };

  const handleClearOriginal = () => {
    setImmediateText('');
    toastHelpers.success('Исходный текст очищен');
  };

  const handleSwapTexts = () => {
    if (hasProcessedText) {
      setImmediateText(processedText);
      toastHelpers.success('Тексты поменяны местами');
    }
  };

  // Определение цвета для счетчиков
  const getStatsColor = (value: number, type: 'characters' | 'lines' | 'words') => {
    if (type === 'characters') {
      if (value > 100000) return 'text-destructive';
      if (value > 50000) return 'text-yellow-500';
      return 'text-muted-foreground';
    }
    if (type === 'lines') {
      if (value > 10000) return 'text-destructive';
      if (value > 5000) return 'text-yellow-500';
      return 'text-muted-foreground';
    }
    return 'text-muted-foreground';
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Мобильная версия - Вкладки */}
      <div className="lg:hidden">
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'input' | 'result')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="input" className="flex items-center gap-2">
              <span>Исходный</span>
              <Badge variant="secondary" className="text-xs">
                {formatStatsShort(originalStats).lines}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="result" className="flex items-center gap-2">
              <span>Результат</span>
              <Badge variant="secondary" className="text-xs">
                {formatStatsShort(processedStats).lines}
              </Badge>
              {hasChanges && (
                <Badge variant="default" className="text-xs ml-1">
                  Изменен
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="mt-4">
            <InputTextCard
              text={immediateText}
              onTextChange={setImmediateText}
              stats={originalStats}
              onPaste={handlePaste}
              onCopy={handleCopyOriginal}
              onClear={handleClearOriginal}
              onLoadFile={onLoadFile}
              isTextPending={isTextPending}
            />
          </TabsContent>

          <TabsContent value="result" className="mt-4">
            <ResultTextCard
              text={processedText}
              stats={processedStats}
              onCopy={handleCopyProcessed}
              onDownload={onDownload}
              onSwap={handleSwapTexts}
              previewInfo={previewInfo}
              hasChanges={hasChanges}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Десктопная версия - Раздельные карточки */}
      <div className="hidden lg:block space-y-6">
        <InputTextCard
          text={immediateText}
          onTextChange={setImmediateText}
          stats={originalStats}
          onPaste={handlePaste}
          onCopy={handleCopyOriginal}
          onClear={handleClearOriginal}
          onLoadFile={onLoadFile}
          isTextPending={isTextPending}
        />

        <ResultTextCard
          text={processedText}
          stats={processedStats}
          onCopy={handleCopyProcessed}
          onDownload={onDownload}
          onSwap={handleSwapTexts}
          previewInfo={previewInfo}
          hasChanges={hasChanges}
        />
      </div>
    </div>
  );
}

// Компонент для исходного текста
function InputTextCard({
  text,
  onTextChange,
  stats,
  onPaste,
  onCopy,
  onClear,
  onLoadFile,
  isTextPending
}: {
  text: string;
  onTextChange: (text: string) => void;
  stats: ReturnType<typeof calculateTextStats>;
  onPaste: () => void;
  onCopy: () => void;
  onClear: () => void;
  onLoadFile: () => void;
  isTextPending: boolean;
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            Исходный текст
            {isTextPending && (
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            )}
          </CardTitle>
          <div className="flex items-center gap-1">
            <Button size="sm" variant="ghost" onClick={onLoadFile} title="Загрузить файл">
              <Upload className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={onPaste} title="Вставить">
              <ClipboardPaste className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={onCopy} disabled={!text} title="Копировать">
              <Copy className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={onClear} disabled={!text} title="Очистить">
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Статистика */}
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant="outline">
            <span className={getStatsColor(stats.characters, 'characters')}>
              {stats.characters.toLocaleString()} символов
            </span>
          </Badge>
          <Badge variant="outline">
            <span className={getStatsColor(stats.words, 'words')}>
              {stats.words.toLocaleString()} слов
            </span>
          </Badge>
          <Badge variant="outline">
            <span className={getStatsColor(stats.lines, 'lines')}>
              {stats.lines.toLocaleString()} строк
            </span>
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="space-y-3">
          <Label htmlFor="original-text" className="sr-only">
            Исходный текст для обработки
          </Label>
          <Textarea
            id="original-text"
            placeholder="Вставьте или введите текст для обработки..."
            value={text}
            onChange={(e) => onTextChange(e.target.value)}
            className="min-h-[300px] lg:min-h-[400px] resize-none font-mono text-sm"
          />
          
          {text && stats.characters > 50000 && (
            <div className="flex items-center gap-2 text-xs text-yellow-600">
              <AlertTriangle className="h-3 w-3" />
              <span>Большой объем текста - операции могут выполняться медленнее</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Компонент для результата
function ResultTextCard({
  text,
  stats,
  onCopy,
  onDownload,
  onSwap,
  previewInfo,
  hasChanges
}: {
  text: string;
  stats: ReturnType<typeof calculateTextStats>;
  onCopy: () => void;
  onDownload: () => void;
  onSwap: () => void;
  previewInfo?: string;
  hasChanges: boolean;
}) {
  return (
    <Card className={hasChanges ? 'border-primary/50' : ''}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            Результат
            {previewInfo && (
              <div className="flex items-center gap-1">
                <Eye className="h-3 w-3 text-primary" />
                <Badge variant="outline" className="text-xs">
                  {previewInfo}
                </Badge>
              </div>
            )}
          </CardTitle>
          <div className="flex items-center gap-1">
            <Button size="sm" variant="ghost" onClick={onSwap} disabled={!text} title="Поменять местами">
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={onCopy} disabled={!text} title="Копировать">
              <Copy className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={onDownload} disabled={!text} title="Скачать">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Статистика */}
        <div className="flex flex-wrap gap-2 text-xs">
          <Badge variant="outline">
            <span className={getStatsColor(stats.characters, 'characters')}>
              {stats.characters.toLocaleString()} символов
            </span>
          </Badge>
          <Badge variant="outline">
            <span className={getStatsColor(stats.words, 'words')}>
              {stats.words.toLocaleString()} слов
            </span>
          </Badge>
          <Badge variant="outline">
            <span className={getStatsColor(stats.lines, 'lines')}>
              {stats.lines.toLocaleString()} строк
            </span>
          </Badge>
          {hasChanges && (
            <Badge variant="default" className="text-xs">
              Изменен
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="space-y-3">
          <Label htmlFor="processed-text" className="sr-only">
            Обработанный текст
          </Label>
          {text ? (
            <ScrollArea className="h-[300px] lg:h-[400px] w-full border rounded-md">
              <Textarea
                id="processed-text"
                value={text}
                readOnly
                className="min-h-[300px] lg:min-h-[400px] resize-none font-mono text-sm border-0 focus:ring-0"
              />
            </ScrollArea>
          ) : (
            <div className="h-[300px] lg:h-[400px] border rounded-md flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Eye className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Результат обработки появится здесь</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// Функция для определения цвета статистики
function getStatsColor(value: number, type: 'characters' | 'lines' | 'words'): string {
  if (type === 'characters') {
    if (value > 100000) return 'text-destructive';
    if (value > 50000) return 'text-yellow-500';
    return 'text-muted-foreground';
  }
  if (type === 'lines') {
    if (value > 10000) return 'text-destructive';
    if (value > 5000) return 'text-yellow-500';
    return 'text-muted-foreground';
  }
  return 'text-muted-foreground';
}