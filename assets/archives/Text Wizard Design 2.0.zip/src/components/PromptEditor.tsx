import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { 
  Plus, 
  Trash2, 
  Copy, 
  Download, 
  Upload, 
  Save, 
  Edit, 
  ChevronDown, 
  ChevronRight,
  Sparkles, 
  Zap, 
  Brain, 
  MessageSquare,
  FileText,
  Settings,
  Eye,
  EyeOff,
  RotateCcw,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';
import { toastHelpers } from './Toast';
import { useDebouncedState } from '../utils/debounce';

interface PromptSection {
  id: string;
  type: 'system' | 'context' | 'instruction' | 'example' | 'output';
  title: string;
  content: string;
  enabled: boolean;
  collapsed?: boolean;
  placeholder?: string;
}

interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  aiModel: 'gpt4' | 'claude' | 'gemini' | 'custom';
  sections: PromptSection[];
  variables: Record<string, string>;
  createdAt: Date;
}

const defaultTemplates: PromptTemplate[] = [
  {
    id: 'text-analysis',
    name: 'Анализ текста',
    description: 'Структурированный анализ текстового контента',
    aiModel: 'gpt4',
    sections: [
      {
        id: 'system-1',
        type: 'system',
        title: 'Системная роль',
        content: 'Ты эксперт по анализу текста. Твоя задача - предоставить детальный и структурированный анализ предоставленного текста.',
        enabled: true,
        placeholder: 'Опишите роль и поведение ИИ...'
      },
      {
        id: 'context-1',
        type: 'context',
        title: 'Контекст задачи',
        content: 'Анализ включает: стиль письма, тональность, ключевые темы, структуру, аудиторию.',
        enabled: true,
        placeholder: 'Дополнительный контекст для задачи...'
      },
      {
        id: 'instruction-1',
        type: 'instruction',
        title: 'Инструкции',
        content: '1. Определи основную тему и подтемы\n2. Оцени тональность (позитивная/негативная/нейтральная)\n3. Проанализируй стиль и структуру\n4. Определи целевую аудиторию\n5. Выдели ключевые моменты',
        enabled: true,
        placeholder: 'Пошаговые инструкции...'
      },
      {
        id: 'output-1',
        type: 'output',
        title: 'Формат вывода',
        content: 'Представь результат в формате:\n\n**Основная тема:** [тема]\n**Тональность:** [оценка]\n**Стиль:** [описание]\n**Аудитория:** [описание]\n**Ключевые моменты:** [список]',
        enabled: true,
        placeholder: 'Желаемый формат ответа...'
      }
    ],
    variables: {},
    createdAt: new Date()
  },
  {
    id: 'content-creation',
    name: 'Создание контента',
    description: 'Генерация качественного контента с учетом целей и аудитории',
    aiModel: 'claude',
    sections: [
      {
        id: 'system-2',
        type: 'system',
        title: 'Системная роль',
        content: 'Ты креативный copywriter с опытом создания контента для различных платформ и аудиторий.',
        enabled: true,
        placeholder: 'Опишите роль и экспертизу...'
      },
      {
        id: 'context-2',
        type: 'context',
        title: 'Контекст',
        content: 'Тема: {{topic}}\nЦелевая аудитория: {{audience}}\nПлатформа: {{platform}}\nТон: {{tone}}',
        enabled: true,
        placeholder: 'Используйте переменные {{variable}} для динамического контента...'
      },
      {
        id: 'instruction-2',
        type: 'instruction',
        title: 'Требования',
        content: '- Создай привлекательный заголовок\n- Используй понятный и увлекательный язык\n- Добавь call-to-action\n- Оптимизируй под целевую аудиторию\n- Соблюдай указанный тон',
        enabled: true,
        placeholder: 'Конкретные требования к контенту...'
      }
    ],
    variables: {
      topic: 'искусственный интеллект',
      audience: 'разработчики',
      platform: 'LinkedIn',
      tone: 'профессиональный'
    },
    createdAt: new Date()
  }
];

const sectionTypeLabels = {
  system: 'Системная роль',
  context: 'Контекст',
  instruction: 'Инструкции',
  example: 'Примеры',
  output: 'Формат вывода'
};

const sectionTypeIcons = {
  system: Settings,
  context: Brain,
  instruction: FileText,
  example: MessageSquare,
  output: Sparkles
};

const aiModelLabels = {
  gpt4: 'GPT-4',
  claude: 'Claude',
  gemini: 'Gemini',
  custom: 'Пользовательская'
};

export function PromptEditor() {
  const [templates, setTemplates] = useState<PromptTemplate[]>(defaultTemplates);
  const [activeTemplate, setActiveTemplate] = useState<PromptTemplate | null>(templates[0]);
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Debounced состояние для предварительного просмотра
  const [immediatePrompt, debouncedPrompt, setImmediatePrompt, isPromptPending] = useDebouncedState('', 300);

  // Проверка размера экрана
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Загрузка сохраненных шаблонов
  useEffect(() => {
    const savedTemplates = localStorage.getItem('promptTemplates');
    if (savedTemplates) {
      try {
        const parsed = JSON.parse(savedTemplates);
        const templatesWithDates = parsed.map((t: any) => ({
          ...t,
          createdAt: new Date(t.createdAt)
        }));
        setTemplates([...defaultTemplates, ...templatesWithDates]);
      } catch (error) {
        console.error('Ошибка загрузки шаблонов:', error);
      }
    }
  }, []);

  // Сохранение шаблонов
  useEffect(() => {
    const customTemplates = templates.filter(t => !defaultTemplates.find(dt => dt.id === t.id));
    localStorage.setItem('promptTemplates', JSON.stringify(customTemplates));
  }, [templates]);

  // Генерация промпта при изменении шаблона или переменных
  useEffect(() => {
    if (activeTemplate) {
      generatePrompt();
    }
  }, [activeTemplate, variables]);

  const generatePrompt = useCallback(() => {
    if (!activeTemplate) return;

    const enabledSections = activeTemplate.sections.filter(s => s.enabled);
    let prompt = '';

    enabledSections.forEach((section, index) => {
      let content = section.content;
      
      // Замена переменных
      Object.entries({ ...activeTemplate.variables, ...variables }).forEach(([key, value]) => {
        content = content.replace(new RegExp(`{{${key}}}`, 'g'), value);
      });

      if (content.trim()) {
        if (index > 0) prompt += '\n\n';
        prompt += `# ${section.title}\n${content}`;
      }
    });

    setGeneratedPrompt(prompt);
    setImmediatePrompt(prompt);
  }, [activeTemplate, variables, setImmediatePrompt]);

  const createNewTemplate = () => {
    const newTemplate: PromptTemplate = {
      id: `template-${Date.now()}`,
      name: 'Новый шаблон',
      description: 'Описание шаблона',
      aiModel: 'gpt4',
      sections: [
        {
          id: `section-${Date.now()}`,
          type: 'system',
          title: 'Системная роль',
          content: '',
          enabled: true,
          placeholder: 'Опишите роль ИИ...'
        }
      ],
      variables: {},
      createdAt: new Date()
    };

    setTemplates(prev => [...prev, newTemplate]);
    setActiveTemplate(newTemplate);
    toastHelpers.success('Новый шаблон создан');
  };

  const updateTemplate = (updatedTemplate: PromptTemplate) => {
    setTemplates(prev => prev.map(t => t.id === updatedTemplate.id ? updatedTemplate : t));
    if (activeTemplate?.id === updatedTemplate.id) {
      setActiveTemplate(updatedTemplate);
    }
  };

  const deleteTemplate = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template && !defaultTemplates.find(dt => dt.id === templateId)) {
      setTemplates(prev => prev.filter(t => t.id !== templateId));
      if (activeTemplate?.id === templateId) {
        setActiveTemplate(templates[0] || null);
      }
      toastHelpers.success('Шаблон удален', template.name);
    } else {
      toastHelpers.error('Нельзя удалить системный шаблон');
    }
  };

  const addSection = (type: PromptSection['type']) => {
    if (!activeTemplate) return;

    const newSection: PromptSection = {
      id: `section-${Date.now()}`,
      type,
      title: sectionTypeLabels[type],
      content: '',
      enabled: true,
      placeholder: `Введите ${sectionTypeLabels[type].toLowerCase()}...`
    };

    const updatedTemplate = {
      ...activeTemplate,
      sections: [...activeTemplate.sections, newSection]
    };

    updateTemplate(updatedTemplate);
  };

  const updateSection = (sectionId: string, updates: Partial<PromptSection>) => {
    if (!activeTemplate) return;

    const updatedTemplate = {
      ...activeTemplate,
      sections: activeTemplate.sections.map(s => 
        s.id === sectionId ? { ...s, ...updates } : s
      )
    };

    updateTemplate(updatedTemplate);
  };

  const removeSection = (sectionId: string) => {
    if (!activeTemplate) return;

    const updatedTemplate = {
      ...activeTemplate,
      sections: activeTemplate.sections.filter(s => s.id !== sectionId)
    };

    updateTemplate(updatedTemplate);
  };

  const updateVariable = (key: string, value: string) => {
    setVariables(prev => ({ ...prev, [key]: value }));
  };

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(generatedPrompt);
      toastHelpers.success('Промпт скопирован в буфер обмена');
    } catch (error) {
      toastHelpers.error('Ошибка копирования');
    }
  };

  const exportTemplate = () => {
    if (!activeTemplate) return;

    try {
      const dataStr = JSON.stringify(activeTemplate, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeTemplate.name.replace(/\s+/g, '-')}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toastHelpers.success('Шаблон экспортирован');
    } catch (error) {
      toastHelpers.error('Ошибка экспорта');
    }
  };

  const importTemplate = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const template = JSON.parse(e.target?.result as string);
            template.id = `imported-${Date.now()}`;
            template.createdAt = new Date();
            setTemplates(prev => [...prev, template]);
            setActiveTemplate(template);
            toastHelpers.success('Шаблон импортирован', template.name);
          } catch (error) {
            toastHelpers.error('Ошибка импорта шаблона');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  if (!activeTemplate) {
    return (
      <div className="container mx-auto max-w-7xl p-4 lg:p-6">
        <div className="text-center py-16">
          <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-medium mb-2">Нет доступных шаблонов</h2>
          <p className="text-muted-foreground mb-6">Создайте новый шаблон для начала работы</p>
          <Button onClick={createNewTemplate}>
            <Plus className="h-4 w-4 mr-2" />
            Создать шаблон
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-7xl p-4 lg:p-6">
      {isMobile ? (
        /* Мобильная версия - оптимизированная */
        <div className="space-y-4">
          <Tabs defaultValue="templates" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="templates" className="text-sm">Шаблоны</TabsTrigger>
              <TabsTrigger value="editor" className="text-sm">Редактор</TabsTrigger>
              <TabsTrigger value="result" className="text-sm">Результат</TabsTrigger>
            </TabsList>

            <TabsContent value="templates" className="mt-4">
              <MobileTemplateSelector
                templates={templates}
                activeTemplate={activeTemplate}
                onSelectTemplate={setActiveTemplate}
                onCreateTemplate={createNewTemplate}
                onDeleteTemplate={deleteTemplate}
                onImportTemplate={importTemplate}
              />
            </TabsContent>

            <TabsContent value="editor" className="mt-4">
              <MobileTemplateEditor
                template={activeTemplate}
                onUpdateTemplate={updateTemplate}
                onAddSection={addSection}
                onUpdateSection={updateSection}
                onRemoveSection={removeSection}
                variables={variables}
                onUpdateVariable={updateVariable}
              />
            </TabsContent>

            <TabsContent value="result" className="mt-4">
              <MobilePromptResult
                prompt={generatedPrompt}
                onCopy={copyPrompt}
                onExport={exportTemplate}
                isPending={isPromptPending}
              />
            </TabsContent>
          </Tabs>
        </div>
      ) : (
        /* Десктопная версия */
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Левая панель - Шаблоны */}
          <div className="lg:col-span-1">
            <TemplateSelector
              templates={templates}
              activeTemplate={activeTemplate}
              onSelectTemplate={setActiveTemplate}
              onCreateTemplate={createNewTemplate}
              onDeleteTemplate={deleteTemplate}
              onImportTemplate={importTemplate}
            />
          </div>

          {/* Центральная панель - Редактор */}
          <div className="lg:col-span-2">
            <TemplateEditor
              template={activeTemplate}
              onUpdateTemplate={updateTemplate}
              onAddSection={addSection}
              onUpdateSection={updateSection}
              onRemoveSection={removeSection}
              variables={variables}
              onUpdateVariable={updateVariable}
            />
          </div>

          {/* Правая панель - Результат */}
          <div className="lg:col-span-1">
            <PromptResult
              prompt={generatedPrompt}
              onCopy={copyPrompt}
              onExport={exportTemplate}
              isPending={isPromptPending}
            />
          </div>
        </div>
      )}
    </div>
  );
}

// Мобильный компонент выбора шаблонов
function MobileTemplateSelector({
  templates,
  activeTemplate,
  onSelectTemplate,
  onCreateTemplate,
  onDeleteTemplate,
  onImportTemplate
}: {
  templates: PromptTemplate[];
  activeTemplate: PromptTemplate;
  onSelectTemplate: (template: PromptTemplate) => void;
  onCreateTemplate: () => void;
  onDeleteTemplate: (id: string) => void;
  onImportTemplate: () => void;
}) {
  return (
    <div className="space-y-3">
      {/* Быстрые действия */}
      <div className="flex gap-2">
        <Button onClick={onCreateTemplate} className="flex-1" size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Создать
        </Button>
        <Button onClick={onImportTemplate} variant="outline" size="sm">
          <Upload className="h-4 w-4" />
        </Button>
      </div>

      {/* Список шаблонов */}
      <div className="space-y-2">
        {templates.map((template) => (
          <div
            key={template.id}
            className={`p-3 rounded-lg border cursor-pointer transition-colors ${
              activeTemplate.id === template.id
                ? 'border-primary bg-primary/10'
                : 'border-border hover:bg-muted/50'
            }`}
            onClick={() => onSelectTemplate(template)}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-sm truncate">{template.name}</h4>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-xs">
                    {aiModelLabels[template.aiModel]}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {template.sections.filter(s => s.enabled).length} секций
                  </Badge>
                </div>
              </div>
              
              {!defaultTemplates.find(dt => dt.id === template.id) && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteTemplate(template.id);
                  }}
                  className="h-6 w-6 p-0 text-destructive hover:text-destructive ml-2"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Мобильный компонент редактора
function MobileTemplateEditor({
  template,
  onUpdateTemplate,
  onAddSection,
  onUpdateSection,
  onRemoveSection,
  variables,
  onUpdateVariable
}: {
  template: PromptTemplate;
  onUpdateTemplate: (template: PromptTemplate) => void;
  onAddSection: (type: PromptSection['type']) => void;
  onUpdateSection: (id: string, updates: Partial<PromptSection>) => void;
  onRemoveSection: (id: string) => void;
  variables: Record<string, string>;
  onUpdateVariable: (key: string, value: string) => void;
}) {
  const allVariables = { ...template.variables, ...variables };

  return (
    <div className="space-y-4">
      {/* Основные настройки - компактно */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Настройки</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            value={template.name}
            onChange={(e) => onUpdateTemplate({ ...template, name: e.target.value })}
            placeholder="Название шаблона"
            className="text-base"
          />

          <Select
            value={template.aiModel}
            onValueChange={(value) => onUpdateTemplate({ ...template, aiModel: value as any })}
          >
            <SelectTrigger className="text-base">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(aiModelLabels).map(([value, label]) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Переменные - если есть */}
      {Object.keys(allVariables).length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Переменные
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(allVariables).map(([key, value]) => (
              <div key={key}>
                <Label className="text-sm">{{key}}</Label>
                <Input
                  value={variables[key] || value}
                  onChange={(e) => onUpdateVariable(key, e.target.value)}
                  placeholder={`Значение для {{${key}}}`}
                  className="text-base mt-1"
                />
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Секции */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Секции</CardTitle>
            <Select onValueChange={(value) => onAddSection(value as PromptSection['type'])}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Добавить" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(sectionTypeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    <div className="flex items-center gap-2">
                      <Plus className="h-3 w-3" />
                      <span className="text-sm">{label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>

        <CardContent className="pt-0">
          <div className="space-y-3">
            {template.sections.map((section, index) => (
              <MobileSectionEditor
                key={section.id}
                section={section}
                onUpdate={(updates) => onUpdateSection(section.id, updates)}
                onRemove={() => onRemoveSection(section.id)}
                canRemove={template.sections.length > 1}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Мобильный компонент секции
function MobileSectionEditor({
  section,
  onUpdate,
  onRemove,
  canRemove
}: {
  section: PromptSection;
  onUpdate: (updates: Partial<PromptSection>) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  const IconComponent = sectionTypeIcons[section.type];

  return (
    <Card className={`${section.enabled ? 'border-primary/50' : 'border-dashed'}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Switch
              checked={section.enabled}
              onCheckedChange={(enabled) => onUpdate({ enabled })}
            />
            
            <Collapsible>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onUpdate({ collapsed: !section.collapsed })}
                  className="flex items-center gap-2 p-0 h-auto"
                >
                  {section.collapsed ? (
                    <ChevronRight className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                  <IconComponent className="h-4 w-4" />
                  <span className="font-medium text-sm">{section.title}</span>
                </Button>
              </CollapsibleTrigger>
            </Collapsible>
          </div>

          {canRemove && (
            <Button
              size="sm"
              variant="ghost"
              onClick={onRemove}
              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>

      <Collapsible open={!section.collapsed}>
        <CollapsibleContent>
          <CardContent className="pt-0 space-y-3">
            <Input
              value={section.title}
              onChange={(e) => onUpdate({ title: e.target.value })}
              placeholder="Заголовок секции"
              className="text-base"
            />

            <Textarea
              value={section.content}
              onChange={(e) => onUpdate({ content: e.target.value })}
              placeholder={section.placeholder || 'Введите содержимое...'}
              rows={3}
              className="font-mono text-sm resize-none"
            />
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

// Мобильный компонент результата
function MobilePromptResult({
  prompt,
  onCopy,
  onExport,
  isPending
}: {
  prompt: string;
  onCopy: () => void;
  onExport: () => void;
  isPending: boolean;
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            Промпт
            {isPending && (
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            )}
          </CardTitle>
          <div className="flex gap-1">
            <Button size="sm" variant="ghost" onClick={onExport} className="h-8 w-8 p-0">
              <Download className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" onClick={onCopy} className="h-8 w-8 p-0">
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {prompt ? (
          <ScrollArea className="h-[400px] w-full border rounded-lg">
            <div className="p-3">
              <pre className="text-sm whitespace-pre-wrap font-mono leading-relaxed">
                {prompt}
              </pre>
            </div>
          </ScrollArea>
        ) : (
          <div className="h-[400px] border rounded-lg flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Промпт появится здесь</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Десктопные компоненты - упрощенные версии
function TemplateSelector({ templates, activeTemplate, onSelectTemplate, onCreateTemplate, onDeleteTemplate, onImportTemplate }: any) {
  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium">Шаблоны</CardTitle>
          <div className="flex gap-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="sm" variant="ghost" onClick={onImportTemplate} className="h-8 w-8 p-0">
                    <Upload className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Импорт шаблона</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Button size="sm" variant="ghost" onClick={onCreateTemplate} className="h-8 w-8 p-0">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <ScrollArea className="h-[500px]">
          <div className="space-y-2">
            {templates.map((template: any) => (
              <div
                key={template.id}
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                  activeTemplate.id === template.id
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:bg-muted/50'
                }`}
                onClick={() => onSelectTemplate(template)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate">{template.name}</h4>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {template.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {aiModelLabels[template.aiModel]}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {template.sections.filter((s: any) => s.enabled).length} секций
                      </Badge>
                    </div>
                  </div>
                  
                  {!defaultTemplates.find(dt => dt.id === template.id) && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteTemplate(template.id);
                      }}
                      className="h-6 w-6 p-0 text-destructive hover:text-destructive ml-2"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function TemplateEditor({ template, onUpdateTemplate, onAddSection, onUpdateSection, onRemoveSection, variables, onUpdateVariable }: any) {
  const allVariables = { ...template.variables, ...variables };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-medium">Настройки шаблона</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="template-name">Название</Label>
            <Input
              id="template-name"
              value={template.name}
              onChange={(e) => onUpdateTemplate({ ...template, name: e.target.value })}
              placeholder="Название шаблона"
            />
          </div>

          <div>
            <Label htmlFor="template-description">Описание</Label>
            <Textarea
              id="template-description"
              value={template.description}
              onChange={(e) => onUpdateTemplate({ ...template, description: e.target.value })}
              placeholder="Описание шаблона"
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="ai-model">ИИ-модель</Label>
            <Select
              value={template.aiModel}
              onValueChange={(value) => onUpdateTemplate({ ...template, aiModel: value as any })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(aiModelLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {Object.keys(allVariables).length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Переменные
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {Object.entries(allVariables).map(([key, value]) => (
              <div key={key}>
                <Label htmlFor={`var-${key}`}>{{key}}</Label>
                <Input
                  id={`var-${key}`}
                  value={variables[key] || value}
                  onChange={(e) => onUpdateVariable(key, e.target.value)}
                  placeholder={`Значение для {{${key}}}`}
                />
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-medium">Секции промпта</CardTitle>
            <Select onValueChange={(value) => onAddSection(value as PromptSection['type'])}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Добавить секцию..." />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(sectionTypeLabels).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    <div className="flex items-center gap-2">
                      <Plus className="h-4 w-4" />
                      {label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>

        <CardContent className="pt-0">
          <ScrollArea className="h-[400px]">
            <div className="space-y-4">
              {template.sections.map((section: any, index: number) => (
                <SectionEditor
                  key={section.id}
                  section={section}
                  onUpdate={(updates) => onUpdateSection(section.id, updates)}
                  onRemove={() => onRemoveSection(section.id)}
                  canRemove={template.sections.length > 1}
                />
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

function SectionEditor({ section, onUpdate, onRemove, canRemove }: any) {
  const IconComponent = sectionTypeIcons[section.type];

  return (
    <Card className={`${section.enabled ? 'border-primary/50' : 'border-dashed'}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Switch
              checked={section.enabled}
              onCheckedChange={(enabled) => onUpdate({ enabled })}
            />
            
            <Collapsible>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onUpdate({ collapsed: !section.collapsed })}
                  className="flex items-center gap-2 p-0 h-auto"
                >
                  {section.collapsed ? (
                    <ChevronRight className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                  <IconComponent className="h-4 w-4" />
                  <span className="font-medium">{section.title}</span>
                </Button>
              </CollapsibleTrigger>
            </Collapsible>

            <Badge variant="outline" className="text-xs">
              {sectionTypeLabels[section.type]}
            </Badge>
          </div>

          {canRemove && (
            <Button
              size="sm"
              variant="ghost"
              onClick={onRemove}
              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>

      <Collapsible open={!section.collapsed}>
        <CollapsibleContent>
          <CardContent className="pt-0 space-y-3">
            <div>
              <Label htmlFor={`title-${section.id}`}>Заголовок секции</Label>
              <Input
                id={`title-${section.id}`}
                value={section.title}
                onChange={(e) => onUpdate({ title: e.target.value })}
                placeholder="Заголовок секции"
              />
            </div>

            <div>
              <Label htmlFor={`content-${section.id}`}>Содержимое</Label>
              <Textarea
                id={`content-${section.id}`}
                value={section.content}
                onChange={(e) => onUpdate({ content: e.target.value })}
                placeholder={section.placeholder || 'Введите содержимое...'}
                rows={4}
                className="font-mono text-sm"
              />
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

function PromptResult({ prompt, onCopy, onExport, isPending }: any) {
  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            Готовый промпт
            {isPending && (
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            )}
          </CardTitle>
          <div className="flex gap-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="sm" variant="ghost" onClick={onExport} className="h-8 w-8 p-0">
                    <Download className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Экспорт шаблона</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Button size="sm" variant="ghost" onClick={onCopy} className="h-8 w-8 p-0">
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {prompt ? (
          <ScrollArea className="h-[500px] w-full border rounded-lg">
            <div className="p-4">
              <pre className="text-sm whitespace-pre-wrap font-mono">
                {prompt}
              </pre>
            </div>
          </ScrollArea>
        ) : (
          <div className="h-[500px] border rounded-lg flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Промпт появится здесь</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}