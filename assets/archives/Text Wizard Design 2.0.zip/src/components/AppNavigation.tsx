import React from 'react';
import { AppModule } from '../types';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { FileText, Edit3, Music, Sparkles } from 'lucide-react';

interface AppNavigationProps {
  currentModule: AppModule;
  onModuleChange: (module: AppModule) => void;
  className?: string;
}

const moduleConfig = {
  textProcessor: {
    icon: FileText,
    label: 'Text Processor',
    description: 'Пакетная обработка текста',
    badge: null
  },
  promptEditor: {
    icon: Edit3,
    label: 'Prompt Editor',
    description: 'Редактор промптов для ИИ',
    badge: 'New'
  },
  suno: {
    icon: Music,
    label: 'Suno',
    description: 'Генерация музыки',
    badge: 'Soon'
  }
};

export function AppNavigation({ currentModule, onModuleChange, className = '' }: AppNavigationProps) {
  return (
    <div className={`bg-card border-b border-border ${className}`}>
      <div className="container mx-auto max-w-7xl px-4 py-3">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-semibold">Text Wizard</span>
            </div>
            <Badge variant="outline" className="text-xs">
              v2.0
            </Badge>
          </div>
        </div>

        <nav className="flex flex-wrap gap-2">
          {(Object.keys(moduleConfig) as AppModule[]).map((module) => {
            const config = moduleConfig[module];
            const Icon = config.icon;
            const isActive = currentModule === module;
            const isDisabled = module === 'suno';

            return (
              <Button
                key={module}
                variant={isActive ? "default" : "ghost"}
                size="sm"
                onClick={() => !isDisabled && onModuleChange(module)}
                disabled={isDisabled}
                className={`
                  flex items-center gap-2 px-4 py-2 h-auto
                  ${isActive ? 'bg-primary text-primary-foreground' : 'hover:bg-accent/50'}
                  ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}
                `}
              >
                <Icon className="h-4 w-4" />
                <div className="flex flex-col items-start text-left">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{config.label}</span>
                    {config.badge && (
                      <Badge 
                        variant={config.badge === 'New' ? 'default' : 'secondary'} 
                        className="text-xs h-5"
                      >
                        {config.badge}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground hidden sm:block">
                    {config.description}
                  </span>
                </div>
              </Button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}