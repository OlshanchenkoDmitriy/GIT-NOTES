import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { Eye, EyeOff, RotateCcw, Copy, ArrowRight } from 'lucide-react';
import { compareTextStats, TextStatsDiff } from '../utils/textStats';

interface DiffPreviewProps {
  originalText: string;
  processedText: string;
  operationName?: string;
  isVisible?: boolean;
  onToggleVisibility?: () => void;
  onApply?: () => void;
  onRevert?: () => void;
  className?: string;
}

interface DiffLine {
  type: 'added' | 'removed' | 'unchanged' | 'modified';
  originalIndex?: number;
  processedIndex?: number;
  originalContent: string;
  processedContent: string;
}

export function DiffPreview({
  originalText,
  processedText,
  operationName = 'Операция',
  isVisible = true,
  onToggleVisibility,
  onApply,
  onRevert,
  className = ''
}: DiffPreviewProps) {
  const [viewMode, setViewMode] = useState<'unified' | 'split' | 'stats'>('unified');
  const [showLineNumbers, setShowLineNumbers] = useState(true);

  // Вычисляем diff между текстами
  const diffData = useMemo(() => {
    return calculateDiff(originalText, processedText);
  }, [originalText, processedText]);

  // Статистика изменений
  const stats = useMemo(() => {
    return compareTextStats(originalText, processedText);
  }, [originalText, processedText]);

  const hasChanges = originalText !== processedText;

  if (!isVisible) {
    return (
      <Card className={`border-dashed ${className}`}>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm text-muted-foreground">
              Предварительный просмотр скрыт
            </CardTitle>
            <Button
              size="sm"
              variant="ghost"
              onClick={onToggleVisibility}
              className="h-8"
            >
              <Eye className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className={`${className} ${hasChanges ? 'border-primary/50' : 'border-dashed'}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-sm">Предварительный просмотр</CardTitle>
            {operationName && (
              <Badge variant="outline" className="text-xs">
                {operationName}
              </Badge>
            )}
            {hasChanges && (
              <Badge variant="secondary" className="text-xs">
                {diffData.changes} изменений
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            {onApply && hasChanges && (
              <Button size="sm" variant="default" onClick={onApply}>
                Применить
              </Button>
            )}
            {onRevert && hasChanges && (
              <Button size="sm" variant="outline" onClick={onRevert}>
                <RotateCcw className="h-4 w-4 mr-1" />
                Отменить
              </Button>
            )}
            {onToggleVisibility && (
              <Button
                size="sm"
                variant="ghost"
                onClick={onToggleVisibility}
                title="Скрыть предварительный просмотр"
              >
                <EyeOff className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {!hasChanges ? (
          <div className="text-center py-8 text-muted-foreground">
            <ArrowRight className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Изменений не обнаружено</p>
          </div>
        ) : (
          <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as any)}>
            <div className="flex items-center justify-between mb-3">
              <TabsList className="grid w-fit grid-cols-3">
                <TabsTrigger value="unified" className="text-xs">
                  Единый
                </TabsTrigger>
                <TabsTrigger value="split" className="text-xs">
                  Раздельный
                </TabsTrigger>
                <TabsTrigger value="stats" className="text-xs">
                  Статистика
                </TabsTrigger>
              </TabsList>

              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowLineNumbers(!showLineNumbers)}
                  className="text-xs h-7"
                >
                  {showLineNumbers ? 'Скрыть номера' : 'Показать номера'}
                </Button>
              </div>
            </div>

            <TabsContent value="unified" className="mt-0">
              <UnifiedDiffView 
                diffLines={diffData.lines}
                showLineNumbers={showLineNumbers}
              />
            </TabsContent>

            <TabsContent value="split" className="mt-0">
              <SplitDiffView 
                originalText={originalText}
                processedText={processedText}
                showLineNumbers={showLineNumbers}
              />
            </TabsContent>

            <TabsContent value="stats" className="mt-0">
              <StatsView stats={stats} />
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}

// Компонент единого просмотра diff
function UnifiedDiffView({ 
  diffLines, 
  showLineNumbers 
}: { 
  diffLines: DiffLine[]; 
  showLineNumbers: boolean; 
}) {
  return (
    <ScrollArea className="h-64 w-full rounded-md border">
      <div className="p-2 font-mono text-xs">
        {diffLines.map((line, index) => (
          <div
            key={index}
            className={`flex ${getLineClassName(line.type)} px-2 py-1 hover:bg-muted/30`}
          >
            {showLineNumbers && (
              <span className="w-12 text-muted-foreground text-right mr-3 select-none">
                {line.originalIndex !== undefined ? line.originalIndex + 1 : ''}
              </span>
            )}
            <span className="w-4 text-center mr-2 select-none">
              {line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' '}
            </span>
            <span className="flex-1 whitespace-pre-wrap break-all">
              {line.type === 'removed' ? line.originalContent : line.processedContent}
            </span>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}

// Компонент раздельного просмотра
function SplitDiffView({ 
  originalText, 
  processedText, 
  showLineNumbers 
}: { 
  originalText: string; 
  processedText: string; 
  showLineNumbers: boolean; 
}) {
  const originalLines = originalText.split('\n');
  const processedLines = processedText.split('\n');

  return (
    <div className="grid grid-cols-2 gap-2 h-64">
      {/* Исходный текст */}
      <div className="border rounded">
        <div className="bg-muted px-2 py-1 text-xs font-medium border-b">
          Исходный текст
        </div>
        <ScrollArea className="h-52">
          <div className="p-2 font-mono text-xs">
            {originalLines.map((line, index) => (
              <div key={index} className="flex hover:bg-muted/30 px-1 py-0.5">
                {showLineNumbers && (
                  <span className="w-8 text-muted-foreground text-right mr-2 select-none">
                    {index + 1}
                  </span>
                )}
                <span className="flex-1 whitespace-pre-wrap break-all">
                  {line || ' '}
                </span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Обработанный текст */}
      <div className="border rounded">
        <div className="bg-muted px-2 py-1 text-xs font-medium border-b">
          Результат
        </div>
        <ScrollArea className="h-52">
          <div className="p-2 font-mono text-xs">
            {processedLines.map((line, index) => (
              <div key={index} className="flex hover:bg-muted/30 px-1 py-0.5">
                {showLineNumbers && (
                  <span className="w-8 text-muted-foreground text-right mr-2 select-none">
                    {index + 1}
                  </span>
                )}
                <span className="flex-1 whitespace-pre-wrap break-all">
                  {line || ' '}
                </span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

// Компонент статистики изменений
function StatsView({ stats }: { stats: TextStatsDiff }) {
  const copyStats = async () => {
    try {
      const text = `Изменения:
Символы: ${stats.characters.before} → ${stats.characters.after} (${stats.characters.change >= 0 ? '+' : ''}${stats.characters.change})
Слова: ${stats.words.before} → ${stats.words.after} (${stats.words.change >= 0 ? '+' : ''}${stats.words.change})
Строки: ${stats.lines.before} → ${stats.lines.after} (${stats.lines.change >= 0 ? '+' : ''}${stats.lines.change})`;
      
      await navigator.clipboard.writeText(text);
    } catch (error) {
      console.error('Ошибка копирования статистики:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium">Статистика изменений</h4>
        <Button size="sm" variant="ghost" onClick={copyStats}>
          <Copy className="h-4 w-4" />
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <StatsCard
          label="Символы"
          before={stats.characters.before}
          after={stats.characters.after}
          change={stats.characters.change}
          changePercent={stats.characters.changePercent}
        />
        <StatsCard
          label="Слова"
          before={stats.words.before}
          after={stats.words.after}
          change={stats.words.change}
          changePercent={stats.words.changePercent}
        />
        <StatsCard
          label="Строки"
          before={stats.lines.before}
          after={stats.lines.after}
          change={stats.lines.change}
          changePercent={stats.lines.changePercent}
        />
      </div>
    </div>
  );
}

function StatsCard({ 
  label, 
  before, 
  after, 
  change, 
  changePercent 
}: { 
  label: string;
  before: number;
  after: number;
  change: number;
  changePercent: number;
}) {
  return (
    <div className="p-3 border rounded-lg">
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <div className="text-sm">
        <span className="text-muted-foreground">{before.toLocaleString()}</span>
        <ArrowRight className="h-3 w-3 inline mx-1" />
        <span className="font-medium">{after.toLocaleString()}</span>
      </div>
      <div className={`text-xs mt-1 ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
        {change >= 0 ? '+' : ''}{change.toLocaleString()}
        {changePercent !== 0 && (
          <span className="ml-1">({changePercent >= 0 ? '+' : ''}{changePercent}%)</span>
        )}
      </div>
    </div>
  );
}

// Функция для вычисления diff между текстами
function calculateDiff(original: string, processed: string) {
  const originalLines = original.split('\n');
  const processedLines = processed.split('\n');
  const lines: DiffLine[] = [];
  let changes = 0;
  
  // Простой алгоритм сравнения строк
  const maxLines = Math.max(originalLines.length, processedLines.length);
  
  for (let i = 0; i < maxLines; i++) {
    const originalLine = originalLines[i] || '';
    const processedLine = processedLines[i] || '';
    
    if (originalLine === processedLine) {
      lines.push({
        type: 'unchanged',
        originalIndex: i < originalLines.length ? i : undefined,
        processedIndex: i < processedLines.length ? i : undefined,
        originalContent: originalLine,
        processedContent: processedLine
      });
    } else if (i >= originalLines.length) {
      lines.push({
        type: 'added',
        processedIndex: i,
        originalContent: '',
        processedContent: processedLine
      });
      changes++;
    } else if (i >= processedLines.length) {
      lines.push({
        type: 'removed',
        originalIndex: i,
        originalContent: originalLine,
        processedContent: ''
      });
      changes++;
    } else {
      lines.push({
        type: 'modified',
        originalIndex: i,
        processedIndex: i,
        originalContent: originalLine,
        processedContent: processedLine
      });
      changes++;
    }
  }
  
  return { lines, changes };
}

// Стили для разных типов строк
function getLineClassName(type: DiffLine['type']): string {
  switch (type) {
    case 'added':
      return 'bg-green-500/10 border-l-2 border-green-500';
    case 'removed':
      return 'bg-red-500/10 border-l-2 border-red-500';
    case 'modified':
      return 'bg-yellow-500/10 border-l-2 border-yellow-500';
    case 'unchanged':
    default:
      return '';
  }
}