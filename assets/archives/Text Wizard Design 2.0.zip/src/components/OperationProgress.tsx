import React, { useState, useEffect } from 'react';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Loader2, CheckCircle, XCircle, Clock, X } from 'lucide-react';
import { OperationProgress as OperationProgressType } from '../types';

interface OperationProgressProps {
  operations: OperationProgressType[];
  onCancel?: (operationId: string) => void;
  onDismiss?: (operationId: string) => void;
  className?: string;
}

export function OperationProgress({ 
  operations, 
  onCancel, 
  onDismiss,
  className = '' 
}: OperationProgressProps) {
  const [visibleOperations, setVisibleOperations] = useState(operations);

  useEffect(() => {
    setVisibleOperations(operations);
  }, [operations]);

  const handleDismiss = (operationId: string) => {
    setVisibleOperations(prev => prev.filter(op => op.operationId !== operationId));
    onDismiss?.(operationId);
  };

  if (visibleOperations.length === 0) {
    return null;
  }

  return (
    <div className={`space-y-2 ${className}`}>
      {visibleOperations.map((operation) => (
        <OperationProgressItem
          key={operation.operationId}
          operation={operation}
          onCancel={() => onCancel?.(operation.operationId)}
          onDismiss={() => handleDismiss(operation.operationId)}
        />
      ))}
    </div>
  );
}

interface OperationProgressItemProps {
  operation: OperationProgressType;
  onCancel?: () => void;
  onDismiss?: () => void;
}

function OperationProgressItem({ operation, onCancel, onDismiss }: OperationProgressItemProps) {
  const [shouldAutoHide, setShouldAutoHide] = useState(false);

  // Автоскрытие завершенных операций через 3 секунды
  useEffect(() => {
    if (operation.status === 'completed' || operation.status === 'error') {
      const timer = setTimeout(() => {
        setShouldAutoHide(true);
        onDismiss?.();
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [operation.status, onDismiss]);

  const getStatusIcon = () => {
    switch (operation.status) {
      case 'running':
        return <Loader2 className="h-4 w-4 animate-spin text-primary" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-destructive" />;
      case 'idle':
        return <Clock className="h-4 w-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  const getStatusColor = () => {
    switch (operation.status) {
      case 'running':
        return 'bg-primary';
      case 'completed':
        return 'bg-green-500';
      case 'error':
        return 'bg-destructive';
      case 'idle':
        return 'bg-muted';
      default:
        return 'bg-muted';
    }
  };

  const getStatusText = () => {
    switch (operation.status) {
      case 'running':
        return 'Выполняется...';
      case 'completed':
        return 'Завершено';
      case 'error':
        return 'Ошибка';
      case 'idle':
        return 'Ожидание';
      default:
        return '';
    }
  };

  if (shouldAutoHide) {
    return null;
  }

  return (
    <Card className="border-2 transition-all duration-300 hover:shadow-md">
      <CardContent className="p-3">
        <div className="flex items-center gap-3">
          {/* Иконка статуса */}
          <div className="flex-shrink-0">
            {getStatusIcon()}
          </div>

          {/* Основной контент */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium truncate">
                  Операция #{operation.operationId.slice(-6)}
                </span>
                <Badge 
                  variant={operation.status === 'error' ? 'destructive' : 'secondary'}
                  className="text-xs"
                >
                  {getStatusText()}
                </Badge>
              </div>

              {/* Процент выполнения */}
              {operation.status === 'running' && (
                <span className="text-xs text-muted-foreground font-mono">
                  {Math.round(operation.progress)}%
                </span>
              )}
            </div>

            {/* Прогресс-бар */}
            {operation.status === 'running' && (
              <Progress 
                value={operation.progress} 
                className="w-full h-2 mb-2"
              />
            )}

            {/* Сообщение */}
            {operation.message && (
              <p className="text-xs text-muted-foreground truncate">
                {operation.message}
              </p>
            )}
          </div>

          {/* Кнопки действий */}
          <div className="flex items-center gap-1 flex-shrink-0">
            {operation.status === 'running' && onCancel && (
              <Button
                size="sm"
                variant="ghost"
                onClick={onCancel}
                className="h-8 w-8 p-0"
                title="Отменить"
              >
                <X className="h-3 w-3" />
              </Button>
            )}

            {(operation.status === 'completed' || operation.status === 'error') && onDismiss && (
              <Button
                size="sm"
                variant="ghost"
                onClick={onDismiss}
                className="h-8 w-8 p-0"
                title="Скрыть"
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>
        </div>

        {/* Полная прогресс-полоса для завершенных операций */}
        {operation.status === 'completed' && (
          <div className="w-full h-1 bg-green-500 rounded-full mt-2 animate-pulse" />
        )}

        {operation.status === 'error' && (
          <div className="w-full h-1 bg-destructive rounded-full mt-2" />
        )}
      </CardContent>
    </Card>
  );
}

// Компонент мини-индикатора прогресса для встраивания в другие элементы
export function MiniProgressIndicator({ 
  progress, 
  status, 
  size = 'sm' 
}: { 
  progress: number; 
  status: OperationProgressType['status']; 
  size?: 'xs' | 'sm' | 'md' 
}) {
  const sizeClasses = {
    xs: 'h-1 w-8',
    sm: 'h-2 w-12',
    md: 'h-3 w-16'
  };

  if (status === 'idle') return null;

  return (
    <div className="flex items-center gap-2">
      {status === 'running' && (
        <div className="flex items-center gap-1">
          <Loader2 className="h-3 w-3 animate-spin text-primary" />
          <Progress 
            value={progress} 
            className={sizeClasses[size]}
          />
          <span className="text-xs text-muted-foreground font-mono">
            {Math.round(progress)}%
          </span>
        </div>
      )}

      {status === 'completed' && (
        <div className="flex items-center gap-1">
          <CheckCircle className="h-3 w-3 text-green-500" />
          <span className="text-xs text-green-600">Готово</span>
        </div>
      )}

      {status === 'error' && (
        <div className="flex items-center gap-1">
          <XCircle className="h-3 w-3 text-destructive" />
          <span className="text-xs text-destructive">Ошибка</span>
        </div>
      )}
    </div>
  );
}

// Хук для управления прогрессом операций
export function useOperationProgress() {
  const [operations, setOperations] = useState<OperationProgressType[]>([]);

  const startOperation = (operationId: string, message?: string) => {
    setOperations(prev => [
      ...prev.filter(op => op.operationId !== operationId),
      {
        operationId,
        progress: 0,
        status: 'running',
        message: message || 'Запуск операции...'
      }
    ]);
  };

  const updateProgress = (operationId: string, progress: number, message?: string) => {
    setOperations(prev => prev.map(op => 
      op.operationId === operationId 
        ? { ...op, progress: Math.max(0, Math.min(100, progress)), message: message || op.message }
        : op
    ));
  };

  const completeOperation = (operationId: string, message?: string) => {
    setOperations(prev => prev.map(op =>
      op.operationId === operationId
        ? { ...op, progress: 100, status: 'completed', message: message || 'Операция завершена' }
        : op
    ));
  };

  const errorOperation = (operationId: string, message?: string) => {
    setOperations(prev => prev.map(op =>
      op.operationId === operationId
        ? { ...op, status: 'error', message: message || 'Произошла ошибка' }
        : op
    ));
  };

  const cancelOperation = (operationId: string) => {
    setOperations(prev => prev.filter(op => op.operationId !== operationId));
  };

  const clearCompleted = () => {
    setOperations(prev => prev.filter(op => op.status === 'running' || op.status === 'idle'));
  };

  const clearAll = () => {
    setOperations([]);
  };

  return {
    operations,
    startOperation,
    updateProgress,
    completeOperation,
    errorOperation,
    cancelOperation,
    clearCompleted,
    clearAll
  };
}