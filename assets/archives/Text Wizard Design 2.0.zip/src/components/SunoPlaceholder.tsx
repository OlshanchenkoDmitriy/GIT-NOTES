import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Music, Sparkles, Clock, Zap } from 'lucide-react';

export function SunoPlaceholder() {
  return (
    <div className="container mx-auto max-w-7xl p-4 lg:p-6">
      <div className="max-w-2xl mx-auto text-center space-y-8">
        {/* Основная иконка */}
        <div className="relative">
          <div className="w-24 h-24 mx-auto bg-gradient-to-br from-primary to-primary/70 rounded-2xl flex items-center justify-center shadow-lg">
            <Music className="h-12 w-12 text-primary-foreground" />
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
        </div>

        {/* Заголовок и статус */}
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-3">
            <h1 className="text-3xl font-semibold">Suno AI</h1>
            <Badge variant="secondary" className="text-sm px-3 py-1">
              Скоро
            </Badge>
          </div>
          
          <p className="text-lg text-muted-foreground max-w-lg mx-auto">
            Интеграция с Suno AI для генерации музыки на основе текстовых промптов находится в разработке
          </p>
        </div>

        {/* Планируемые функции */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-lg mx-auto">
          <Card className="border-dashed">
            <CardContent className="p-6 text-center space-y-3">
              <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-medium">Генерация музыки</h3>
              <p className="text-sm text-muted-foreground">
                Создание треков из текстовых описаний
              </p>
            </CardContent>
          </Card>

          <Card className="border-dashed">
            <CardContent className="p-6 text-center space-y-3">
              <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-medium">Быстрое создание</h3>
              <p className="text-sm text-muted-foreground">
                Генерация за несколько минут
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Кнопка уведомления */}
        <div className="space-y-4">
          <Button size="lg" disabled className="px-8">
            <Music className="h-5 w-5 mr-2" />
            Уведомить о готовности
          </Button>
          
          <p className="text-sm text-muted-foreground">
            Мы уведомим вас, когда функция станет доступна
          </p>
        </div>

        {/* Дополнительная информация */}
        <div className="bg-muted/50 rounded-lg p-6 space-y-3">
          <h4 className="font-medium">Что ожидать:</h4>
          <ul className="text-sm text-muted-foreground space-y-2 text-left max-w-md mx-auto">
            <li>• Генерация музыки из текстовых описаний</li>
            <li>• Различные музыкальные стили и жанры</li>
            <li>• Настройка длительности и темпа</li>
            <li>• Экспорт в популярные аудиоформаты</li>
            <li>• Интеграция с промптами из Prompt Editor</li>
          </ul>
        </div>
      </div>
    </div>
  );
}