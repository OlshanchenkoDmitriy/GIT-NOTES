export type OperationType = 
  | 'removeCharacters'
  | 'regexReplace'
  | 'changeCase'
  | 'deduplicate'
  | 'removeEmptyLines'
  | 'trimWhitespace'
  | 'addPrefixSuffix'
  | 'sortLines'
  | 'addLineNumbers'
  | 'sliceHead';

export interface Operation {
  id: string;
  type: OperationType;
  enabled: boolean;
  settings: Record<string, any>;
  collapsed?: boolean;
}

export interface Preset {
  id: string;
  name: string;
  operations: Operation[];
  createdAt: Date;
}

export type CaseType = 'uppercase' | 'lowercase' | 'capitalize' | 'sentence' | 'invert';
export type SortType = 'alphabetical' | 'length' | 'random';
export type LineNumberFormat = 'decimal' | 'parentheses' | 'padded' | 'brackets';

export interface TextProcessingState {
  originalText: string;
  processedText: string;
  operations: Operation[];
  currentPreset?: Preset;
}

// Новые типы для системы истории
export interface HistoryState {
  originalText: string;
  operations: Operation[];
  timestamp: number;
  description: string;
}

export interface AppState {
  originalText: string;
  processedText: string;
  operations: Operation[];
  presets: Preset[];
  previewUpTo: string | null;
  history: HistoryState[];
  currentHistoryIndex: number;
}

// Типы для тостов
export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  id: string;
  type: ToastType;
  title: string;
  message?: string;
  duration?: number;
}

// Типы для статистики текста
export interface TextStats {
  characters: number;
  charactersWithoutSpaces: number;
  lines: number;
  words: number;
}

// Типы для модулей приложения
export type AppModule = 'textProcessor' | 'promptEditor' | 'suno';

// Типы для Prompt Editor
export interface PromptSection {
  id: string;
  type: 'context' | 'task' | 'format' | 'constraints' | 'examples' | 'custom';
  title: string;
  content: string;
  placeholder: string;
  enabled: boolean;
  collapsed?: boolean;
}

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  modelType: 'gpt' | 'claude' | 'gemini' | 'sora' | 'universal';
  sections: PromptSection[];
  createdAt: Date;
}

export interface PromptVariable {
  id: string;
  name: string;
  value: string;
  description?: string;
}

// Типы для прогресса операций
export interface OperationProgress {
  operationId: string;
  progress: number;
  status: 'idle' | 'running' | 'completed' | 'error';
  message?: string;
}