import { TextStats } from '../types';

export function calculateTextStats(text: string): TextStats {
  if (!text) {
    return {
      characters: 0,
      charactersWithoutSpaces: 0,
      lines: 0,
      words: 0
    };
  }

  const characters = text.length;
  const charactersWithoutSpaces = text.replace(/\s/g, '').length;
  const lines = text.split('\n').length;
  
  // Подсчет слов с учетом различных разделителей
  const words = text
    .trim()
    .split(/\s+/)
    .filter(word => word.length > 0)
    .length;

  return {
    characters,
    charactersWithoutSpaces,
    lines,
    words
  };
}

// Дополнительные метрики для расширенной статистики
export interface ExtendedTextStats extends TextStats {
  paragraphs: number;
  sentences: number;
  averageWordsPerSentence: number;
  averageCharactersPerWord: number;
  readingTimeMinutes: number;
  emptyLines: number;
  uniqueWords: number;
  duplicateLines: number;
}

export function calculateExtendedTextStats(text: string): ExtendedTextStats {
  const basic = calculateTextStats(text);
  
  if (!text.trim()) {
    return {
      ...basic,
      paragraphs: 0,
      sentences: 0,
      averageWordsPerSentence: 0,
      averageCharactersPerWord: 0,
      readingTimeMinutes: 0,
      emptyLines: 0,
      uniqueWords: 0,
      duplicateLines: 0
    };
  }

  const lines = text.split('\n');
  const emptyLines = lines.filter(line => line.trim() === '').length;
  
  // Подсчет параграфов (группы непустых строк)
  let paragraphs = 0;
  let currentParagraphHasContent = false;
  
  for (const line of lines) {
    if (line.trim()) {
      currentParagraphHasContent = true;
    } else if (currentParagraphHasContent) {
      paragraphs++;
      currentParagraphHasContent = false;
    }
  }
  if (currentParagraphHasContent) paragraphs++;

  // Подсчет предложений
  const sentences = text
    .split(/[.!?]+/)
    .filter(sentence => sentence.trim().length > 0)
    .length;

  // Средние значения
  const averageWordsPerSentence = sentences > 0 ? basic.words / sentences : 0;
  const averageCharactersPerWord = basic.words > 0 ? basic.charactersWithoutSpaces / basic.words : 0;
  
  // Время чтения (средняя скорость 200 слов в минуту)
  const readingTimeMinutes = basic.words / 200;

  // Уникальные слова
  const words = text
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(word => word.length > 0);
  const uniqueWords = new Set(words).size;

  // Дублирующиеся строки
  const lineMap = new Map<string, number>();
  lines.forEach(line => {
    const trimmed = line.trim();
    if (trimmed) {
      lineMap.set(trimmed, (lineMap.get(trimmed) || 0) + 1);
    }
  });
  const duplicateLines = Array.from(lineMap.values()).filter(count => count > 1).length;

  return {
    ...basic,
    paragraphs,
    sentences,
    averageWordsPerSentence: Math.round(averageWordsPerSentence * 10) / 10,
    averageCharactersPerWord: Math.round(averageCharactersPerWord * 10) / 10,
    readingTimeMinutes: Math.round(readingTimeMinutes * 10) / 10,
    emptyLines,
    uniqueWords,
    duplicateLines
  };
}

// Сравнение статистики до и после
export interface TextStatsDiff {
  characters: { before: number; after: number; change: number; changePercent: number };
  words: { before: number; after: number; change: number; changePercent: number };
  lines: { before: number; after: number; change: number; changePercent: number };
}

export function compareTextStats(beforeText: string, afterText: string): TextStatsDiff {
  const before = calculateTextStats(beforeText);
  const after = calculateTextStats(afterText);

  const calculateChange = (beforeVal: number, afterVal: number) => {
    const change = afterVal - beforeVal;
    const changePercent = beforeVal > 0 ? (change / beforeVal) * 100 : 0;
    return { before: beforeVal, after: afterVal, change, changePercent: Math.round(changePercent * 10) / 10 };
  };

  return {
    characters: calculateChange(before.characters, after.characters),
    words: calculateChange(before.words, after.words),
    lines: calculateChange(before.lines, after.lines)
  };
}

// Форматирование статистики для отображения (исправленное название функции)
export function formatStats(stats: TextStats): string {
  return `${stats.characters} символов, ${stats.words} слов, ${stats.lines} строк`;
}

// Оригинальная функция для совместимости
export function formatTextStats(stats: TextStats): string {
  return formatStats(stats);
}

export function formatExtendedTextStats(stats: ExtendedTextStats): Record<string, string> {
  return {
    'Символы': stats.characters.toLocaleString(),
    'Символы без пробелов': stats.charactersWithoutSpaces.toLocaleString(),
    'Слова': stats.words.toLocaleString(),
    'Строки': stats.lines.toLocaleString(),
    'Параграфы': stats.paragraphs.toLocaleString(),
    'Предложения': stats.sentences.toLocaleString(),
    'Слов в предложении': stats.averageWordsPerSentence.toString(),
    'Символов в слове': stats.averageCharactersPerWord.toString(),
    'Время чтения': `${stats.readingTimeMinutes} мин`,
    'Пустые строки': stats.emptyLines.toLocaleString(),
    'Уникальные слова': stats.uniqueWords.toLocaleString(),
    'Дублирующиеся строки': stats.duplicateLines.toLocaleString()
  };
}

// Краткое форматирование для UI компонентов
export function formatStatsShort(stats: TextStats): { characters: string; words: string; lines: string } {
  return {
    characters: stats.characters.toLocaleString(),
    words: stats.words.toLocaleString(),
    lines: stats.lines.toLocaleString()
  };
}

// Форматирование с изменениями
export function formatStatsWithChange(current: TextStats, previous?: TextStats): string {
  if (!previous) {
    return formatStats(current);
  }

  const diff = compareTextStats(
    formatStats(previous),
    formatStats(current)
  );

  const parts = [];
  
  if (diff.characters.change !== 0) {
    const sign = diff.characters.change > 0 ? '+' : '';
    parts.push(`символы: ${current.characters} (${sign}${diff.characters.change})`);
  } else {
    parts.push(`символы: ${current.characters}`);
  }

  if (diff.words.change !== 0) {
    const sign = diff.words.change > 0 ? '+' : '';
    parts.push(`слова: ${current.words} (${sign}${diff.words.change})`);
  } else {
    parts.push(`слова: ${current.words}`);
  }

  if (diff.lines.change !== 0) {
    const sign = diff.lines.change > 0 ? '+' : '';
    parts.push(`строки: ${current.lines} (${sign}${diff.lines.change})`);
  } else {
    parts.push(`строки: ${current.lines}`);
  }

  return parts.join(', ');
}

// Оценка сложности текста для операций
export function assessTextComplexity(text: string): 'low' | 'medium' | 'high' {
  const stats = calculateTextStats(text);
  
  if (stats.characters < 1000) return 'low';
  if (stats.characters < 10000) return 'medium';
  return 'high';
}

// Рекомендации по производительности
export function getPerformanceRecommendations(text: string): string[] {
  const complexity = assessTextComplexity(text);
  const stats = calculateTextStats(text);
  const recommendations: string[] = [];

  if (complexity === 'high') {
    recommendations.push('Большой объем текста. Операции могут выполняться медленнее.');
  }

  if (stats.lines > 10000) {
    recommendations.push('Много строк. Рекомендуется разбить на части для быстрой обработки.');
  }

  if (stats.characters > 100000) {
    recommendations.push('Очень большой файл. Рассмотрите использование потоковой обработки.');
  }

  return recommendations;
}

// Валидация текста
export function validateTextInput(text: string): { isValid: boolean; errors: string[]; warnings: string[] } {
  const errors: string[] = [];
  const warnings: string[] = [];
  const stats = calculateTextStats(text);

  // Проверка на слишком большой размер
  if (stats.characters > 1000000) { // 1MB
    errors.push('Текст слишком большой (максимум 1MB)');
  } else if (stats.characters > 100000) { // 100KB
    warnings.push('Большой объем текста может замедлить обработку');
  }

  // Проверка на слишком много строк
  if (stats.lines > 50000) {
    errors.push('Слишком много строк (максимум 50,000)');
  } else if (stats.lines > 10000) {
    warnings.push('Много строк - рекомендуется разбить файл');
  }

  // Проверка на пустой текст
  if (stats.characters === 0) {
    warnings.push('Текст пустой');
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}

// Получение информации о кодировке и специальных символах
export function analyzeTextEncoding(text: string): {
  hasUnicode: boolean;
  hasEmoji: boolean;
  hasSpecialChars: boolean;
  encoding: string;
  issues: string[];
} {
  const issues: string[] = [];
  
  // Проверка на Unicode символы
  const hasUnicode = /[^\u0000-\u007F]/.test(text);
  
  // Проверка на эмодзи
  const hasEmoji = /[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/u.test(text);
  
  // Проверка на специальные символы
  const hasSpecialChars = /[^\w\s\p{P}]/u.test(text);
  
  // Определение кодировки (упрощенно)
  let encoding = 'ASCII';
  if (hasUnicode) {
    encoding = 'UTF-8';
  }
  
  // Проверка на проблемные символы
  if (/\uFFFD/.test(text)) {
    issues.push('Обнаружены символы замещения (возможна неправильная кодировка)');
  }
  
  if (/[\u0000-\u001F]/.test(text)) {
    issues.push('Обнаружены управляющие символы');
  }
  
  return {
    hasUnicode,
    hasEmoji,
    hasSpecialChars,
    encoding,
    issues
  };
}

// Создание отчета о тексте
export function createTextReport(text: string): {
  stats: ExtendedTextStats;
  validation: ReturnType<typeof validateTextInput>;
  encoding: ReturnType<typeof analyzeTextEncoding>;
  complexity: 'low' | 'medium' | 'high';
  recommendations: string[];
} {
  return {
    stats: calculateExtendedTextStats(text),
    validation: validateTextInput(text),
    encoding: analyzeTextEncoding(text),
    complexity: assessTextComplexity(text),
    recommendations: getPerformanceRecommendations(text)
  };
}