import { useEffect, useState, useRef, useCallback } from 'react';

// Базовая функция debounce
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
}

// React хук для debounced значения
export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}

// Хук для debounced функции с возможностью отмены
export function useDebouncedCallback<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): [(...args: Parameters<T>) => void, () => void] {
  const callbackRef = useRef(callback);
  const timeoutRef = useRef<NodeJS.Timeout>();

  // Обновляем ref при изменении callback
  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  const debouncedCallback = useCallback((...args: Parameters<T>) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      callbackRef.current(...args);
    }, delay);
  }, [delay]);

  const cancel = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = undefined;
    }
  }, []);

  // Очистка при размонтировании
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return [debouncedCallback, cancel];
}

// Хук для debounced состояния с немедленным обновлением UI
export function useDebouncedState<T>(
  initialValue: T,
  delay: number = 300
): [T, T, (value: T) => void, boolean] {
  const [immediateValue, setImmediateValue] = useState<T>(initialValue);
  const [debouncedValue, setDebouncedValue] = useState<T>(initialValue);
  const [isPending, setIsPending] = useState(false);

  useEffect(() => {
    if (immediateValue === debouncedValue) {
      setIsPending(false);
      return;
    }

    setIsPending(true);
    const handler = setTimeout(() => {
      setDebouncedValue(immediateValue);
      setIsPending(false);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [immediateValue, debouncedValue, delay]);

  const setValue = useCallback((value: T) => {
    setImmediateValue(value);
  }, []);

  return [immediateValue, debouncedValue, setValue, isPending];
}

// Специализированный хук для поиска с возможностью отмены
export function useSearchDebounce(
  onSearch: (query: string) => void,
  delay: number = 300
): [(query: string) => void, () => void, boolean] {
  const [isSearching, setIsSearching] = useState(false);
  const searchTimeoutRef = useRef<NodeJS.Timeout>();

  const search = useCallback((query: string) => {
    // Очищаем предыдущий таймер
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    // Если пустой запрос - выполняем сразу
    if (!query.trim()) {
      setIsSearching(false);
      onSearch('');
      return;
    }

    setIsSearching(true);
    searchTimeoutRef.current = setTimeout(() => {
      onSearch(query);
      setIsSearching(false);
    }, delay);
  }, [onSearch, delay]);

  const cancelSearch = useCallback(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
      setIsSearching(false);
    }
  }, []);

  // Очистка при размонтировании
  useEffect(() => {
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, []);

  return [search, cancelSearch, isSearching];
}

// Throttle функция для ограничения частоты вызовов
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// React хук для throttled функции
export function useThrottledCallback<T extends (...args: any[]) => any>(
  callback: T,
  limit: number
): (...args: Parameters<T>) => void {
  const callbackRef = useRef(callback);
  const throttleRef = useRef<boolean>(false);

  useEffect(() => {
    callbackRef.current = callback;
  }, [callback]);

  return useCallback((...args: Parameters<T>) => {
    if (!throttleRef.current) {
      callbackRef.current(...args);
      throttleRef.current = true;
      setTimeout(() => {
        throttleRef.current = false;
      }, limit);
    }
  }, [limit]);
}