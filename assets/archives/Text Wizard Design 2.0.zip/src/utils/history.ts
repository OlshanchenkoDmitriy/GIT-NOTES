import { Operation } from '../types';

export interface HistoryState {
  originalText: string;
  operations: Operation[];
  timestamp: number;
  description: string;
}

export interface HistoryInfo {
  canUndo: boolean;
  canRedo: boolean;
  currentIndex: number;
  totalStates: number;
  currentDescription?: string;
}

export class HistoryManager {
  private history: HistoryState[] = [];
  private currentIndex: number = -1;
  private maxSize: number;

  constructor(maxSize: number = 50) {
    this.maxSize = maxSize;
  }

  pushState(originalText: string, operations: Operation[], description: string): void {
    // Удаляем все состояния после текущего индекса (для новой ветки истории)
    this.history = this.history.slice(0, this.currentIndex + 1);

    // Создаем новое состояние
    const newState: HistoryState = {
      originalText,
      operations: JSON.parse(JSON.stringify(operations)), // Глубокое копирование
      timestamp: Date.now(),
      description
    };

    // Добавляем новое состояние
    this.history.push(newState);
    this.currentIndex = this.history.length - 1;

    // Удаляем старые состояния если превышен лимит
    if (this.history.length > this.maxSize) {
      this.history.shift();
      this.currentIndex--;
    }
  }

  undo(): HistoryState | null {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      return JSON.parse(JSON.stringify(this.history[this.currentIndex]));
    }
    return null;
  }

  redo(): HistoryState | null {
    if (this.currentIndex < this.history.length - 1) {
      this.currentIndex++;
      return JSON.parse(JSON.stringify(this.history[this.currentIndex]));
    }
    return null;
  }

  getHistoryInfo(): HistoryInfo {
    return {
      canUndo: this.currentIndex > 0,
      canRedo: this.currentIndex < this.history.length - 1,
      currentIndex: this.currentIndex,
      totalStates: this.history.length,
      currentDescription: this.history[this.currentIndex]?.description
    };
  }

  clear(): void {
    this.history = [];
    this.currentIndex = -1;
  }

  getCurrentState(): HistoryState | null {
    if (this.currentIndex >= 0 && this.currentIndex < this.history.length) {
      return JSON.parse(JSON.stringify(this.history[this.currentIndex]));
    }
    return null;
  }

  getStateAt(index: number): HistoryState | null {
    if (index >= 0 && index < this.history.length) {
      return JSON.parse(JSON.stringify(this.history[index]));
    }
    return null;
  }

  // Получить список последних N описаний для UI
  getRecentDescriptions(count: number = 5): string[] {
    const start = Math.max(0, this.currentIndex - count + 1);
    const end = this.currentIndex + 1;
    return this.history.slice(start, end).map(state => state.description).reverse();
  }

  // Сжатие истории (удаление промежуточных состояний для экономии памяти)
  compress(): void {
    if (this.history.length <= 10) return;

    // Оставляем первое, последнее и каждое 3-е состояние
    const compressed: HistoryState[] = [];
    for (let i = 0; i < this.history.length; i++) {
      if (i === 0 || i === this.history.length - 1 || i % 3 === 0) {
        compressed.push(this.history[i]);
      }
    }

    this.history = compressed;
    this.currentIndex = Math.min(this.currentIndex, this.history.length - 1);
  }

  // Экспорт истории для отладки
  exportHistory(): string {
    return JSON.stringify({
      history: this.history,
      currentIndex: this.currentIndex,
      maxSize: this.maxSize
    }, null, 2);
  }

  // Импорт истории
  importHistory(historyData: string): boolean {
    try {
      const data = JSON.parse(historyData);
      if (data.history && Array.isArray(data.history)) {
        this.history = data.history;
        this.currentIndex = data.currentIndex || 0;
        this.maxSize = data.maxSize || 50;
        return true;
      }
    } catch (error) {
      console.error('Ошибка импорта истории:', error);
    }
    return false;
  }
}