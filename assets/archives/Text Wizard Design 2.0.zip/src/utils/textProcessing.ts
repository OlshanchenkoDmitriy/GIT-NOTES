import { Operation, OperationType, CaseType, SortType, LineNumberFormat } from '../types';

export const operationLabels: Record<OperationType, string> = {
  removeCharacters: 'Удаление символов',
  regexReplace: 'Регулярные выражения',
  changeCase: 'Изменение регистра',
  deduplicate: 'Удаление дубликатов',
  removeEmptyLines: 'Удаление пустых строк',
  trimWhitespace: 'Обрезка пробелов',
  addPrefixSuffix: 'Префикс/Суффикс',
  sortLines: 'Сортировка строк',
  addLineNumbers: 'Номера строк',
  sliceHead: 'Обрезка начала'
};

export function createOperation(type: OperationType): Operation {
  const baseOperation = {
    id: Math.random().toString(36).substr(2, 9),
    type,
    enabled: true,
    collapsed: false
  };

  switch (type) {
    case 'removeCharacters':
      return {
        ...baseOperation,
        settings: {
          characters: '',
          treatChainsAsTokens: false
        }
      };

    case 'regexReplace':
      return {
        ...baseOperation,
        settings: {
          pattern: '',
          replacement: '',
          flags: 'g',
          highlightMatches: true
        }
      };

    case 'changeCase':
      return {
        ...baseOperation,
        settings: {
          caseType: 'lowercase' as CaseType
        }
      };

    case 'deduplicate':
      return {
        ...baseOperation,
        settings: {
          caseSensitive: true,
          keepFirst: true
        }
      };

    case 'removeEmptyLines':
      return {
        ...baseOperation,
        settings: {
          includeWhitespaceOnly: true
        }
      };

    case 'trimWhitespace':
      return {
        ...baseOperation,
        settings: {
          trimStart: true,
          trimEnd: true,
          perLine: true
        }
      };

    case 'addPrefixSuffix':
      return {
        ...baseOperation,
        settings: {
          prefix: '',
          suffix: '',
          applyToEmptyLines: false
        }
      };

    case 'sortLines':
      return {
        ...baseOperation,
        settings: {
          sortType: 'alphabetical' as SortType,
          ascending: true,
          caseSensitive: false
        }
      };

    case 'addLineNumbers':
      return {
        ...baseOperation,
        settings: {
          format: 'decimal' as LineNumberFormat,
          startNumber: 1,
          separator: '. ',
          padZeros: false
        }
      };

    case 'sliceHead':
      return {
        ...baseOperation,
        settings: {
          characters: 100,
          preserveWords: true,
          addEllipsis: true
        }
      };

    default:
      return baseOperation;
  }
}

export function processText(text: string, operations: Operation[]): string {
  let result = text;
  
  const enabledOperations = operations.filter(op => op.enabled);
  
  for (const operation of enabledOperations) {
    try {
      result = applySingleOperation(result, operation);
    } catch (error) {
      console.error(`Ошибка в операции ${operation.type}:`, error);
      // Продолжаем обработку, не прерывая цепочку
    }
  }
  
  return result;
}

function applySingleOperation(text: string, operation: Operation): string {
  switch (operation.type) {
    case 'removeCharacters':
      return removeCharacters(text, operation.settings);
    
    case 'regexReplace':
      return regexReplace(text, operation.settings);
    
    case 'changeCase':
      return changeCase(text, operation.settings);
    
    case 'deduplicate':
      return deduplicate(text, operation.settings);
    
    case 'removeEmptyLines':
      return removeEmptyLines(text, operation.settings);
    
    case 'trimWhitespace':
      return trimWhitespace(text, operation.settings);
    
    case 'addPrefixSuffix':
      return addPrefixSuffix(text, operation.settings);
    
    case 'sortLines':
      return sortLines(text, operation.settings);
    
    case 'addLineNumbers':
      return addLineNumbers(text, operation.settings);
    
    case 'sliceHead':
      return sliceHead(text, operation.settings);
    
    default:
      return text;
  }
}

function removeCharacters(text: string, settings: { characters: string; treatChainsAsTokens: boolean }): string {
  if (!settings.characters) return text;
  
  if (settings.treatChainsAsTokens) {
    // Обрабатываем цепочки символов как отдельные токены
    const tokens = settings.characters.split('').filter(char => char.trim());
    let result = text;
    
    for (const token of tokens) {
      const regex = new RegExp(escapeRegex(token) + '+', 'g');
      result = result.replace(regex, '');
    }
    
    return result;
  } else {
    // Удаляем каждый символ отдельно
    const regex = new RegExp(`[${escapeRegex(settings.characters)}]`, 'g');
    return text.replace(regex, '');
  }
}

function regexReplace(text: string, settings: { pattern: string; replacement: string; flags: string }): string {
  if (!settings.pattern) return text;
  
  try {
    const regex = new RegExp(settings.pattern, settings.flags || 'g');
    return text.replace(regex, settings.replacement || '');
  } catch (error) {
    throw new Error(`Неверное регулярное выражение: ${error}`);
  }
}

function changeCase(text: string, settings: { caseType: CaseType }): string {
  switch (settings.caseType) {
    case 'uppercase':
      return text.toUpperCase();
    
    case 'lowercase':
      return text.toLowerCase();
    
    case 'capitalize':
      return text.toLowerCase().replace(/\b\w/g, char => char.toUpperCase());
    
    case 'sentence':
      return text.toLowerCase().replace(/(^\w|\.\s+\w)/g, char => char.toUpperCase());
    
    case 'invert':
      return text.split('').map(char => {
        return char === char.toUpperCase() ? char.toLowerCase() : char.toUpperCase();
      }).join('');
    
    default:
      return text;
  }
}

function deduplicate(text: string, settings: { caseSensitive: boolean; keepFirst: boolean }): string {
  const lines = text.split('\n');
  const seen = new Set<string>();
  const result: string[] = [];
  
  const processLine = (line: string) => settings.caseSensitive ? line : line.toLowerCase();
  
  if (settings.keepFirst) {
    for (const line of lines) {
      const processedLine = processLine(line);
      if (!seen.has(processedLine)) {
        seen.add(processedLine);
        result.push(line);
      }
    }
  } else {
    // Оставляем последние вхождения
    for (let i = lines.length - 1; i >= 0; i--) {
      const line = lines[i];
      const processedLine = processLine(line);
      if (!seen.has(processedLine)) {
        seen.add(processedLine);
        result.unshift(line);
      }
    }
  }
  
  return result.join('\n');
}

function removeEmptyLines(text: string, settings: { includeWhitespaceOnly: boolean }): string {
  const lines = text.split('\n');
  
  if (settings.includeWhitespaceOnly) {
    return lines.filter(line => line.trim() !== '').join('\n');
  } else {
    return lines.filter(line => line !== '').join('\n');
  }
}

function trimWhitespace(text: string, settings: { trimStart: boolean; trimEnd: boolean; perLine: boolean }): string {
  if (settings.perLine) {
    const lines = text.split('\n');
    return lines.map(line => {
      let result = line;
      if (settings.trimStart) result = result.replace(/^\s+/, '');
      if (settings.trimEnd) result = result.replace(/\s+$/, '');
      return result;
    }).join('\n');
  } else {
    let result = text;
    if (settings.trimStart) result = result.replace(/^\s+/, '');
    if (settings.trimEnd) result = result.replace(/\s+$/, '');
    return result;
  }
}

function addPrefixSuffix(text: string, settings: { prefix: string; suffix: string; applyToEmptyLines: boolean }): string {
  const lines = text.split('\n');
  
  return lines.map(line => {
    if (!settings.applyToEmptyLines && line.trim() === '') {
      return line;
    }
    return (settings.prefix || '') + line + (settings.suffix || '');
  }).join('\n');
}

function sortLines(text: string, settings: { sortType: SortType; ascending: boolean; caseSensitive: boolean }): string {
  const lines = text.split('\n');
  
  const sortedLines = [...lines].sort((a, b) => {
    let compareA = settings.caseSensitive ? a : a.toLowerCase();
    let compareB = settings.caseSensitive ? b : b.toLowerCase();
    
    let comparison = 0;
    
    switch (settings.sortType) {
      case 'alphabetical':
        comparison = compareA.localeCompare(compareB);
        break;
      
      case 'length':
        comparison = a.length - b.length;
        if (comparison === 0) {
          comparison = compareA.localeCompare(compareB);
        }
        break;
      
      case 'random':
        comparison = Math.random() - 0.5;
        break;
      
      default:
        comparison = 0;
    }
    
    return settings.ascending ? comparison : -comparison;
  });
  
  return sortedLines.join('\n');
}

function addLineNumbers(text: string, settings: { format: LineNumberFormat; startNumber: number; separator: string; padZeros: boolean }): string {
  const lines = text.split('\n');
  const totalLines = lines.length;
  const padLength = settings.padZeros ? totalLines.toString().length : 0;
  
  return lines.map((line, index) => {
    const lineNumber = index + settings.startNumber;
    let formattedNumber = lineNumber.toString();
    
    if (settings.padZeros && padLength > 0) {
      formattedNumber = formattedNumber.padStart(padLength, '0');
    }
    
    switch (settings.format) {
      case 'decimal':
        return formattedNumber + (settings.separator || '. ') + line;
      
      case 'parentheses':
        return '(' + formattedNumber + ')' + (settings.separator || ' ') + line;
      
      case 'padded':
        return formattedNumber.padStart(Math.max(3, padLength), '0') + (settings.separator || '. ') + line;
      
      case 'brackets':
        return '[' + formattedNumber + ']' + (settings.separator || ' ') + line;
      
      default:
        return formattedNumber + (settings.separator || '. ') + line;
    }
  }).join('\n');
}

function sliceHead(text: string, settings: { characters: number; preserveWords: boolean; addEllipsis: boolean }): string {
  if (text.length <= settings.characters) {
    return text;
  }
  
  let sliced = text.substring(0, settings.characters);
  
  if (settings.preserveWords) {
    // Находим последний пробел, чтобы не обрезать слова
    const lastSpace = sliced.lastIndexOf(' ');
    if (lastSpace > settings.characters * 0.8) { // Используем только если не слишком далеко от границы
      sliced = sliced.substring(0, lastSpace);
    }
  }
  
  if (settings.addEllipsis) {
    sliced += '...';
  }
  
  return sliced;
}

function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Функция для подсчета совпадений regex
export function countRegexMatches(text: string, pattern: string, flags: string = 'g'): number {
  if (!pattern) return 0;
  
  try {
    const regex = new RegExp(pattern, flags);
    const matches = text.match(regex);
    return matches ? matches.length : 0;
  } catch (error) {
    return 0;
  }
}

// Функция для подсветки совпадений regex
export function highlightRegexMatches(text: string, pattern: string, flags: string = 'g'): string {
  if (!pattern) return text;
  
  try {
    const regex = new RegExp(pattern, flags);
    return text.replace(regex, (match) => `<mark>${match}</mark>`);
  } catch (error) {
    return text;
  }
}