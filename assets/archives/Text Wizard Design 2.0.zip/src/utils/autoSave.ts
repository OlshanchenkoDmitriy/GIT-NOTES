import { useEffect, useRef, useCallback, useState } from 'react';

export interface AutoSaveConfig {
  interval?: number; // Интервал в миллисекундах (по умолчанию 30 секунд)
  key: string; // Ключ для localStorage
  enabled?: boolean; // Включено ли автосохранение
  onSave?: (data: any) => void; // Колбэк при сохранении
  onLoad?: (data: any) => void; // Колбэк при загрузке
  onError?: (error: Error) => void; // Колбэк при ошибке
}

export interface AutoSaveStatus {
  lastSaved: Date | null;
  isEnabled: boolean;
  hasChanges: boolean;
  isSaving: boolean;
}

// Основной хук для автосохранения
export function useAutoSave<T>(
  data: T,
  config: AutoSaveConfig
): [AutoSaveStatus, () => void, () => void] {
  const {
    interval = 30000, // 30 секунд
    key,
    enabled = true,
    onSave,
    onLoad,
    onError
  } = config;

  const [status, setStatus] = useState<AutoSaveStatus>({
    lastSaved: null,
    isEnabled: enabled,
    hasChanges: false,
    isSaving: false
  });

  const intervalRef = useRef<NodeJS.Timeout>();
  const lastDataRef = useRef<T>(data);
  const hasInitializedRef = useRef(false);

  // Функция сохранения
  const saveData = useCallback(async () => {
    if (!enabled) return;

    try {
      setStatus(prev => ({ ...prev, isSaving: true }));
      
      const serializedData = JSON.stringify(data);
      localStorage.setItem(key, serializedData);
      
      // Сохраняем метаданные
      const metadata = {
        timestamp: Date.now(),
        dataSize: serializedData.length,
        version: '1.0'
      };
      localStorage.setItem(`${key}_metadata`, JSON.stringify(metadata));

      setStatus(prev => ({
        ...prev,
        lastSaved: new Date(),
        hasChanges: false,
        isSaving: false
      }));

      onSave?.(data);
    } catch (error) {
      setStatus(prev => ({ ...prev, isSaving: false }));
      onError?.(error as Error);
      console.error('Ошибка автосохранения:', error);
    }
  }, [data, key, enabled, onSave, onError]);

  // Функция загрузки
  const loadData = useCallback(() => {
    try {
      const savedData = localStorage.getItem(key);
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        
        // Загружаем метаданные
        const metadataString = localStorage.getItem(`${key}_metadata`);
        if (metadataString) {
          const metadata = JSON.parse(metadataString);
          setStatus(prev => ({
            ...prev,
            lastSaved: new Date(metadata.timestamp)
          }));
        }

        onLoad?.(parsedData);
        return parsedData;
      }
    } catch (error) {
      onError?.(error as Error);
      console.error('Ошибка загрузки автосохранения:', error);
    }
    return null;
  }, [key, onLoad, onError]);

  // Принудительное сохранение
  const forceSave = useCallback(() => {
    saveData();
  }, [saveData]);

  // Очистка автосохранения
  const clearSave = useCallback(() => {
    try {
      localStorage.removeItem(key);
      localStorage.removeItem(`${key}_metadata`);
      setStatus(prev => ({
        ...prev,
        lastSaved: null,
        hasChanges: false
      }));
    } catch (error) {
      onError?.(error as Error);
    }
  }, [key, onError]);

  // Отслеживание изменений данных
  useEffect(() => {
    if (!hasInitializedRef.current) {
      hasInitializedRef.current = true;
      return;
    }

    const hasChanged = JSON.stringify(data) !== JSON.stringify(lastDataRef.current);
    if (hasChanged) {
      setStatus(prev => ({ ...prev, hasChanges: true }));
      lastDataRef.current = data;
    }
  }, [data]);

  // Настройка интервала автосохранения
  useEffect(() => {
    if (!enabled) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      return;
    }

    intervalRef.current = setInterval(() => {
      if (status.hasChanges && !status.isSaving) {
        saveData();
      }
    }, interval);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [enabled, interval, saveData, status.hasChanges, status.isSaving]);

  // Сохранение при закрытии страницы
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (status.hasChanges) {
        saveData();
        // Предупреждение пользователя о несохраненных изменениях
        e.preventDefault();
        e.returnValue = '';
      }
    };

    const handlePageHide = () => {
      if (status.hasChanges) {
        saveData();
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    window.addEventListener('pagehide', handlePageHide);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      window.removeEventListener('pagehide', handlePageHide);
    };
  }, [status.hasChanges, saveData]);

  // Обновление статуса enabled
  useEffect(() => {
    setStatus(prev => ({ ...prev, isEnabled: enabled }));
  }, [enabled]);

  return [status, forceSave, clearSave];
}

// Специализированный хук для Text Wizard
export function useTextProcessorAutoSave(
  originalText: string,
  operations: any[],
  presets: any[]
) {
  const data = {
    originalText,
    operations,
    presets,
    timestamp: Date.now()
  };

  const [status, forceSave, clearSave] = useAutoSave(data, {
    key: 'textProcessor_autoSave',
    interval: 30000, // 30 секунд
    enabled: true,
    onSave: (data) => {
      console.log('Автосохранение выполнено:', new Date().toLocaleTimeString());
    },
    onError: (error) => {
      console.error('Ошибка автосохранения:', error);
    }
  });

  // Функция загрузки сохраненного состояния
  const loadSavedState = useCallback(() => {
    try {
      const savedData = localStorage.getItem('textProcessor_autoSave');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        return {
          originalText: parsed.originalText || '',
          operations: parsed.operations || [],
          presets: parsed.presets || [],
          timestamp: parsed.timestamp
        };
      }
    } catch (error) {
      console.error('Ошибка загрузки автосохранения:', error);
    }
    return null;
  }, []);

  return {
    status,
    forceSave,
    clearSave,
    loadSavedState
  };
}

// Хук для отображения статуса автосохранения
export function useAutoSaveIndicator(status: AutoSaveStatus) {
  const [indicator, setIndicator] = useState<{
    text: string;
    color: 'success' | 'warning' | 'error' | 'info';
    visible: boolean;
  }>({
    text: '',
    color: 'info',
    visible: false
  });

  useEffect(() => {
    if (status.isSaving) {
      setIndicator({
        text: 'Сохранение...',
        color: 'info',
        visible: true
      });
    } else if (status.hasChanges) {
      setIndicator({
        text: 'Есть несохраненные изменения',
        color: 'warning',
        visible: true
      });
    } else if (status.lastSaved) {
      const timeAgo = Math.floor((Date.now() - status.lastSaved.getTime()) / 1000);
      if (timeAgo < 60) {
        setIndicator({
          text: `Сохранено ${timeAgo}s назад`,
          color: 'success',
          visible: true
        });
      } else {
        setIndicator({
          text: `Сохранено ${status.lastSaved.toLocaleTimeString()}`,
          color: 'info',
          visible: false
        });
      }
    } else {
      setIndicator({
        text: '',
        color: 'info',
        visible: false
      });
    }
  }, [status]);

  return indicator;
}

// Утилита для очистки старых автосохранений
export function cleanupOldAutoSaves(maxAge: number = 7 * 24 * 60 * 60 * 1000) { // 7 дней
  const keys = Object.keys(localStorage);
  const autoSaveKeys = keys.filter(key => key.includes('_autoSave') || key.includes('_metadata'));
  
  autoSaveKeys.forEach(key => {
    try {
      if (key.includes('_metadata')) {
        const metadata = JSON.parse(localStorage.getItem(key) || '{}');
        if (metadata.timestamp && Date.now() - metadata.timestamp > maxAge) {
          localStorage.removeItem(key);
          localStorage.removeItem(key.replace('_metadata', ''));
          console.log(`Удалено старое автосохранение: ${key}`);
        }
      }
    } catch (error) {
      console.error('Ошибка при очистке автосохранений:', error);
    }
  });
}