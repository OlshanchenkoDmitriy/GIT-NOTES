
  # Text Wizard Design

  This is a code bundle for Text Wizard Design. The original project is available at https://www.figma.com/design/Rf0xKvFfSq4f79PdKaqcO4/Text-Wizard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  